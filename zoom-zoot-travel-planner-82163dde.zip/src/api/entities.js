import { base44 } from './base44Client';


export const Itinerary = base44.entities.Itinerary;

export const ExchangeRateSnapshot = base44.entities.ExchangeRateSnapshot;



// auth sdk:
export const User = base44.auth;