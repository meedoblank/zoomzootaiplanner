import { base44 } from './base44Client';


export const getFlights = base44.functions.getFlights;

export const getHotels = base44.functions.getHotels;

export const createStripeCheckout = base44.functions.createStripeCheckout;

export const fetchExchangeRates = base44.functions.fetchExchangeRates;

export const getGooglePlaces = base44.functions.getGooglePlaces;

export const getDirections = base44.functions.getDirections;

export const stripeWebhookHandle = base44.functions.stripeWebhookHandle;

export const processChat = base44.functions.processChat;

