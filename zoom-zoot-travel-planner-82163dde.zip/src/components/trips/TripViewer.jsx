
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { X, Mail, Plane, Hotel, Calendar, ExternalLink, DollarSign, MapPin } from 'lucide-react';

export default function TripViewer({ trip, onClose, onEmailTrip }) {
    if (!trip || !trip.generated_plan) return null;

    const plan = trip.generated_plan;

    const ResultCard = ({ icon: Icon, title, children, color }) => (
        <div className={`bg-white rounded-xl p-4 sm:p-6 border-l-4 border-${color}-500 mb-6`}>
            <h3 className={`text-lg font-bold text-[#297479] mb-3 flex items-center`}>
                <Icon className={`w-5 h-5 mr-3 text-${color}-500`} />
                {title}
            </h3>
            {children}
        </div>
    );

    return (
        <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={onClose}
        >
            <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="bg-gray-50 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col"
                onClick={(e) => e.stopPropagation()}
            >
                {/* Header */}
                <div className="relative p-4 sm:p-6 border-b bg-gradient-to-r from-[#297479] to-[#aab624] text-white">
                    <Button variant="ghost" size="icon" onClick={onClose} className="absolute top-3 right-3 text-white hover:bg-white/20 z-10">
                        <X className="w-5 h-5" />
                    </Button>
                    <div className="flex flex-col gap-3">
                        <div>
                            <h2 className="text-xl sm:text-2xl font-bold pr-10">{trip.title}</h2>
                            <div className="flex flex-wrap gap-2 mt-2 text-xs">
                                <Badge variant="secondary" className="bg-white/20 text-white border-none">
                                    <Calendar className="w-3 h-3 mr-1.5"/>{trip.duration} days
                                </Badge>
                                <Badge variant="secondary" className="bg-white/20 text-white border-none">
                                    <DollarSign className="w-3 h-3 mr-1.5"/>{trip.budget}
                                </Badge>
                                <Badge variant="secondary" className="bg-white/20 text-white border-none">
                                    <MapPin className="w-3 h-3 mr-1.5"/>{trip.travel_style}
                                </Badge>
                            </div>
                        </div>
                        <div>
                            <Button 
                                onClick={() => onEmailTrip(trip)}
                                className="bg-[#f67a24] hover:bg-[#f67a24]/90 text-white"
                                size="sm"
                            >
                                <Mail className="w-4 h-4 mr-2" />
                                Email Planner
                            </Button>
                        </div>
                    </div>
                </div>

                {/* Content */}
                <div className="p-4 sm:p-6 overflow-y-auto">
                    {/* Summary */}
                    <div className="mb-6">
                        <p className="text-center text-gray-700 bg-white p-4 rounded-xl border border-gray-200">
                            {plan.summary}
                        </p>
                    </div>

                    {/* Flight Options */}
                    {plan.flights && plan.flights.length > 0 && (
                        <ResultCard icon={Plane} title="Flight Options" color="teal">
                            <div className="space-y-3">
                                {plan.flights.map((flight, i) => (
                                    <div key={i} className="flex flex-col sm:flex-row justify-between sm:items-center p-3 bg-gray-100 rounded-lg gap-2">
                                        <div>
                                            <p className="font-semibold">{flight.airline}</p>
                                            <p className="text-sm text-gray-600">{flight.details}</p>
                                        </div>
                                        <div className="text-left sm:text-right flex flex-row sm:flex-col items-center sm:items-end gap-2 sm:gap-0 w-full sm:w-auto">
                                            <p className="font-bold text-orange-500">${flight.price}</p>
                                            {flight.link && (
                                                <Button 
                                                    size="sm" 
                                                    variant="outline"
                                                    className="mt-0 sm:mt-1 text-xs"
                                                    onClick={() => window.open(flight.link, '_blank')}
                                                >
                                                    <ExternalLink className="w-3 h-3 mr-1" />
                                                    Book
                                                </Button>
                                            )}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </ResultCard>
                    )}

                    {/* Accommodations */}
                    {plan.accommodations && plan.accommodations.length > 0 && (
                        <ResultCard icon={Hotel} title="Accommodation" color="orange">
                            <div className="space-y-3">
                                {plan.accommodations.map((acc, i) => (
                                    <div key={i} className="flex flex-col sm:flex-row justify-between sm:items-center p-3 bg-gray-100 rounded-lg gap-2">
                                        <div>
                                            <p className="font-semibold">{acc.name}</p>
                                            <p className="text-sm text-gray-600">{acc.details}</p>
                                        </div>
                                        <div className="text-left sm:text-right flex flex-row sm:flex-col items-center sm:items-end gap-2 sm:gap-0 w-full sm:w-auto">
                                            <p className="font-bold text-orange-500">${acc.price_per_night}/night</p>
                                            {acc.link && (
                                                <Button 
                                                    size="sm" 
                                                    variant="outline"
                                                    className="mt-0 sm:mt-1 text-xs"
                                                    onClick={() => window.open(acc.link, '_blank')}
                                                >
                                                    <ExternalLink className="w-3 h-3 mr-1" />
                                                    Book
                                                </Button>
                                            )}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </ResultCard>
                    )}

                    {/* Daily Itinerary */}
                    {plan.daily_itinerary && plan.daily_itinerary.length > 0 && (
                        <ResultCard icon={Calendar} title="Your Itinerary" color="lime">
                            <div className="space-y-4">
                                {plan.daily_itinerary.map((day, i) => (
                                    <div key={i} className="border-l-4 border-teal-200 pl-4 py-1">
                                        <h4 className="font-semibold">Day {day.day}: {day.title}</h4>
                                        {day.activities && Array.isArray(day.activities) ? (
                                            <div className="space-y-4 mt-2">
                                                {day.activities.map((activity, actIndex) => (
                                                    <div key={actIndex} className="relative pl-6">
                                                        <div className="absolute left-0 top-1 h-full border-l-2 border-dashed border-gray-300"></div>
                                                        <div className="absolute left-[-5px] top-1.5 w-4 h-4 bg-teal-500 rounded-full border-2 border-white"></div>
                                                        <p className="font-semibold text-gray-800">{activity.time}: {activity.description}</p>
                                                        {activity.location_query && (
                                                            <p className="text-sm text-gray-600 pl-1">{activity.location_query}</p>
                                                        )}
                                                        {activity.transport_to_next && (
                                                            <div className="mt-2 text-xs italic text-orange-600 pl-1">
                                                                → {activity.transport_to_next}
                                                            </div>
                                                        )}
                                                    </div>
                                                ))}
                                            </div>
                                        ) : (
                                            <p className="text-sm text-gray-600 break-words mt-1">
                                                {typeof day.activities === 'string' ? day.activities : 'No activities listed for this day.'}
                                            </p>
                                        )}
                                    </div>
                                ))}
                            </div>
                        </ResultCard>
                    )}

                    {/* References */}
                    {plan.references && plan.references.length > 0 && (
                        <ResultCard icon={ExternalLink} title="Additional Resources" color="gray">
                            <div className="space-y-2">
                                <p className="text-sm text-gray-600 mb-3">Want to learn more? Check out these helpful resources:</p>
                                {plan.references.map((ref, i) => (
                                    <div key={i} className="flex items-center">
                                        <ExternalLink className="w-4 h-4 mr-2 text-gray-500" />
                                        <a 
                                            href={ref.url} 
                                            target="_blank" 
                                            rel="noopener noreferrer"
                                            className="text-blue-600 hover:text-blue-800 underline text-sm break-all"
                                        >
                                            {ref.title || ref.url}
                                        </a>
                                    </div>
                                ))}
                            </div>
                        </ResultCard>
                    )}
                </div>
            </motion.div>
        </motion.div>
    );
}
