import React from 'react';

const popularRequestsData = [
    { title: "Cultural Bali", description: "5 days - Culture & Food", emoji: "🌺", borderColor: "border-orange-500", tags: ["🏛️ Temples", "🍜 Local Cuisine"] },
    { title: "Vietnam Backpacking", description: "2 weeks - Budget Travel", emoji: "🏔️", borderColor: "border-lime-500", tags: ["🎒 Adventure", "💰 Budget"] },
    { title: "Luxury Thailand", description: "10 days - Beaches & Luxury", emoji: "🏝️", borderColor: "border-red-500", tags: ["🏖️ Beaches", "✨ Luxury"] },
    { title: "City Explorer", description: "1 week - Singapore & Malaysia", emoji: "🌆", borderColor: "border-teal-500", tags: ["🏙️ Urban", "🛍️ Shopping"] },
    { title: "Philippines Islands", description: "3 weeks - Island Hopping", emoji: "🐠", borderColor: "border-orange-500", tags: ["🏝️ Islands", "🤿 Diving"] },
    { title: "Cambodia History", description: "4 days - Angkor Wat", emoji: "🏛️", borderColor: "border-yellow-500", tags: ["📜 History", "📸 Photography"] },
];

export default function PopularRequests({ onSelectRequest }) {
    return (
        <div className="glass-effect rounded-3xl p-6 phone-tray floating-animation">
            <div className="text-center mb-6">
                <h2 className="text-xl font-bold section-title mb-2">Popular Requests</h2>
                <div className="w-12 h-1 bg-gradient-to-r from-orange-500 to-red-500 mx-auto rounded-full"></div>
            </div>
            
            <div className="space-y-5">
                {popularRequestsData.map((request, index) => (
                    <div key={index} className={`popular-request rounded-2xl p-5 border-l-4 ${request.borderColor} cursor-pointer group`} onClick={() => onSelectRequest(request)}>
                        <div className="flex items-start justify-between">
                            <div className="flex-1">
                                <h3 className="font-bold text-[#297479] text-lg group-hover:text-white transition-colors">{request.title}</h3>
                                <p className="text-sm text-gray-600 group-hover:text-gray-100 mt-1">{request.description}</p>
                                <div className="flex flex-wrap items-center mt-3 text-xs gap-2">
                                    {request.tags.map(tag => (
                                       <span key={tag} className="bg-gray-100 text-gray-700 px-2 py-1 rounded-full group-hover:bg-white/20 group-hover:text-white">{tag}</span>
                                    ))}
                                </div>
                            </div>
                            <div className="text-2xl opacity-60 group-hover:opacity-100 transition-opacity ml-2">{request.emoji}</div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}