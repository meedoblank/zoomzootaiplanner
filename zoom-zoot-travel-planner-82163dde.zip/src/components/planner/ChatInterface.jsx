import React, { useState, useRef, useEffect } from 'react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send, Sparkles } from 'lucide-react';
import MascotIcon from "../MascotIcon";
import { motion, AnimatePresence } from "framer-motion";

const TypingIndicator = () => (
    <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center space-x-2 p-3"
    >
        <MascotIcon width={24} height={24} className="flex-shrink-0" />
        <div className="flex items-center space-x-1">
            <span className="w-2 h-2 bg-gray-500 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
            <span className="w-2 h-2 bg-gray-500 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
            <span className="w-2 h-2 bg-gray-500 rounded-full animate-bounce"></span>
        </div>
    </motion.div>
);

export default function ChatInterface({ messages, onSendMessage, isProcessing }) {
    const [inputValue, setInputValue] = useState('');
    const messagesEndRef = useRef(null);
    const inputRef = useRef(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages, isProcessing]);

    // This effect reliably focuses the input after the AI is done processing.
    useEffect(() => {
        if (!isProcessing) {
            inputRef.current?.focus();
        }
    }, [isProcessing]);

    const handleSend = (e) => {
        e.preventDefault();
        if (inputValue.trim()) {
            onSendMessage(inputValue);
            setInputValue('');
        }
    };

    return (
        <div className="glass-effect rounded-3xl p-4 sm:p-6 phone-tray flex flex-col h-full">
            <div className="text-center mb-4">
                 <div className="flex items-center justify-center mx-auto mb-3 mascot-pulse">
                    <MascotIcon width={48} height={48} />
                </div>
                <h2 className="text-xl font-black text-[#297479] mb-1 font-['Jost']">Plan with ZoomZoot</h2>
                <p className="text-sm section-title font-['Libre_Baskerville'] italic">Your AI Travel Assistant</p>
                <div className="w-12 h-1 bg-gradient-to-r from-[#297479] to-[#f67a24] mx-auto rounded-full mt-2"></div>
            </div>

            <div className="flex-grow overflow-y-auto pr-2 -mr-2 mb-4" style={{ maxHeight: 'calc(100vh - 350px)' }}>
                <AnimatePresence>
                    {messages.map((msg, index) => (
                        <motion.div
                            key={index}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.3 }}
                            className={`flex items-end space-x-3 my-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                        >
                            {msg.role === 'assistant' && <MascotIcon width={32} height={32} className="flex-shrink-0" />}
                            <div
                                className={`max-w-xs md:max-w-md p-3 rounded-2xl ${
                                    msg.role === 'user'
                                        ? 'bg-gradient-to-br from-[#f67a24] to-[#d90102] text-white rounded-br-lg'
                                        : 'bg-white text-gray-800 shadow-sm rounded-bl-lg'
                                }`}
                            >
                                <p className="text-sm leading-relaxed">{msg.content}</p>
                            </div>
                        </motion.div>
                    ))}
                </AnimatePresence>
                {isProcessing && <TypingIndicator />}
                <div ref={messagesEndRef} />
            </div>

            <form onSubmit={handleSend} className="flex items-center space-x-2 mt-auto">
                <Input
                    ref={inputRef}
                    type="text"
                    placeholder="Type your message..."
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    className="flex-grow bg-white/80 rounded-xl focus:outline-none ring-1 ring-inset ring-gray-300 focus:ring-green-500"
                    disabled={isProcessing}
                    autoFocus
                />
                <Button 
                    type="submit" 
                    className="bg-gradient-to-br from-[#297479] to-[#aab624] text-white rounded-xl" 
                    size="icon"
                    disabled={isProcessing}
                >
                    <Send className="w-5 h-5" />
                </Button>
            </form>
        </div>
    );
}