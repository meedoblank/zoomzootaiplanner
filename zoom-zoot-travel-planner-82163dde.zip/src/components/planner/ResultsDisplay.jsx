
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Itinerary as ItineraryEntity } from "@/api/entities";
import { User } from "@/api/entities";
import { createStripeCheckout } from '@/api/functions';
import { Plane, Hotel, Calendar, Mail, CheckCircle, AlertCircle, Download, Wand2, Bot, Rocket, Sparkles, ExternalLink, Bookmark, Crown, Eye, Lock, Zap, Star, Wallet, Info } from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";
import { motion, AnimatePresence } from "framer-motion";
import MascotIcon from '../MascotIcon';
import { createPageUrl } from "@/utils";

export default function ResultsDisplay({ plan, requestData, onFineTune, isGenerating }) {
    const { toast } = useToast();
    const [isSaving, setIsSaving] = useState(false);
    const [fineTunePrompt, setFineTunePrompt] = useState("");
    const [userSubscription, setUserSubscription] = useState('free');

    React.useEffect(() => {
        loadUserSubscription();
    }, []);

    const loadUserSubscription = async () => {
        try {
            const user = await User.me();
            setUserSubscription(user.subscription_type || 'free');
        } catch (error) {
            console.log('Could not load user subscription:', error);
            setUserSubscription('free');
        }
    };

    const handleUpgrade = async (planType, itineraryId = null) => {
        console.log('Starting checkout for:', planType, itineraryId);
        setIsSaving(true);
        
        toast({
            title: "Redirecting to checkout...",
            description: "Please wait while we prepare your payment...",
        });

        try {
            console.log('Calling createStripeCheckout function...');
            const response = await createStripeCheckout({ planType, itineraryId });
            console.log('Function response:', response);

            // Handle different possible response structures
            let sessionUrl = null;
            if (response?.data?.sessionUrl) {
                sessionUrl = response.data.sessionUrl;
            } else if (response?.sessionUrl) {
                sessionUrl = response.sessionUrl;
            } else if (typeof response === 'string' && response.startsWith('https://checkout.stripe.com')) {
                sessionUrl = response;
            }

            console.log('Extracted sessionUrl:', sessionUrl);

            if (sessionUrl) {
                console.log('Redirecting to Stripe checkout at top level...');
                // Fix: Use window.top.location.href for redirect to ensure it works even if in an iframe
                window.top.location.href = sessionUrl;
                return; // Don't set isSaving to false since we're redirecting
            } else {
                console.error('No valid session URL found in response:', response);
                throw new Error("Could not create a checkout session. Please try again.");
            }
        } catch (error) {
            console.error(`Failed to initiate ${planType} checkout:`, error);
            
            let errorMessage = "Could not connect to payment processor. Please try again.";
            if (error.message) {
                errorMessage = error.message;
            } else if (error.response?.data?.error) {
                errorMessage = error.response.data.error;
            }
            
            toast({
                variant: "destructive",
                title: "Checkout Failed",
                description: errorMessage,
            });
            setIsSaving(false);
        }
    };

    const isFreeTier = userSubscription === 'free';
    const isStandardTier = userSubscription === 'standard';
    const isProTier = userSubscription === 'pro' || userSubscription === 'premium';

    // Check if user mentioned food-related terms in their original request
    const hasFoodInRequest = React.useMemo(() => {
        if (!requestData.description) return false;
        const foodKeywords = ['food', 'restaurant', 'eat', 'dining', 'cuisine', 'street food', 'local food', 'culinary', 'meal', 'breakfast', 'lunch', 'dinner'];
        const description = requestData.description.toLowerCase();
        return foodKeywords.some(keyword => description.includes(keyword));
    }, [requestData.description]);

    // Generate restaurant suggestion for the refine prompt placeholder
    const getRestaurantSuggestion = () => {
        if (hasFoodInRequest) return "Tell me what you'd like to change...";
        return "Want to try some amazing local restaurants where you'll be exploring? Just say 'add restaurant recommendations' or tell me what you'd like to change...";
    };
    
    if (!plan) return null;

    const ResultCard = ({ icon: Icon, title, children, color, isLocked = false }) => (
        <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className={`bg-white rounded-xl p-6 border-l-4 border-${color}-500 printable-card ${isLocked ? 'opacity-75' : ''}`}>
            <h3 className={`text-lg font-bold text-[#297479] mb-3 flex items-center printable-title`}>
                <Icon className={`w-5 h-5 mr-3 text-${color}-500`} />
                {title}
                {isLocked && <Lock className="w-4 h-4 ml-2 text-gray-400" />}
                {plan._hasRealFlights && title === "Flight Options" && (
                    <span className="ml-2 text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">Live Prices</span>
                )}
            </h3>
            {children}
        </motion.div>
    );

    const EnhancedWalletCard = ({ walletData }) => {
        if (!walletData) return null;
        return (
            <ResultCard icon={Wallet} title="Enhanced Global Wallet" color="purple">
                <div className="space-y-3 text-sm">
                    {walletData.cost_per_person_breakdown && (
                        <div>
                            <h5 className="font-semibold text-purple-800">Cost Per Person Breakdown</h5>
                            <p className="text-gray-700 bg-purple-50 p-2 rounded-md">{walletData.cost_per_person_breakdown}</p>
                        </div>
                    )}
                    {walletData.tipping_guidance && (
                        <div>
                            <h5 className="font-semibold text-purple-800">Tipping Guidance</h5>
                            <p className="text-gray-700 bg-purple-50 p-2 rounded-md">{walletData.tipping_guidance}</p>
                        </div>
                    )}
                    {walletData.payment_method_notes && (
                        <div>
                            <h5 className="font-semibold text-purple-800">Payment Method Notes</h5>
                            <p className="text-gray-700 bg-purple-50 p-2 rounded-md">{walletData.payment_method_notes}</p>
                        </div>
                    )}
                     {walletData.daily_budget_tracking_summary && (
                        <div>
                            <h5 className="font-semibold text-purple-800">Daily Budget Summary</h5>
                            <p className="text-gray-700 bg-purple-50 p-2 rounded-md">{walletData.daily_budget_tracking_summary}</p>
                        </div>
                    )}
                </div>
            </ResultCard>
        );
    };

    return (
        <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-8 col-span-1 lg:col-span-3 printable-container">
             <div className="glass-effect rounded-2xl p-4 md:p-8">
                {/* Free Preview Header - ALWAYS show for free users */}
                {isFreeTier && (
                    <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-4 mb-6 text-center">
                        <div className="flex items-center justify-center mb-2">
                            <Eye className="w-5 h-5 text-blue-600 mr-2" />
                            <h3 className="text-lg font-bold text-blue-800">Free Preview</h3>
                        </div>
                        <p className="text-blue-700 text-sm">This is a preview of your personalized travel plan. Upgrade to save, edit, and get full access!</p>
                    </div>
                )}

                <h2 className="text-3xl font-bold text-[#297479] mb-4 text-center printable-title">{plan.title || "Your Personalized Travel Plan"}</h2>
                
                <div className="text-center text-sm text-gray-600 mb-2">Budget: <span className="font-semibold">{requestData.budget}</span></div>
                
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 text-center text-xs sm:text-sm text-yellow-800 mb-6">
                    <p>⚠️ <strong>Please Note:</strong> The selected daily budget does not include flights or accommodation costs. Expenses vary across Southeast Asia. Spend wisely! 👍</p>
                </div>

                <p className="text-center text-gray-700 bg-gray-100 p-4 rounded-xl mb-6">{plan.summary}</p>
                
                <div className="space-y-6 mt-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {plan.flights && plan.flights.length > 0 && <ResultCard icon={Plane} title="Flight Options" color="teal">
                            <div className="space-y-3">
                                {plan.flights?.slice(0, isFreeTier ? 1 : 3).map((flight, i) => (
                                    <div key={i} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                                        <div>
                                            <p className="font-semibold">{flight.airline}</p>
                                            <p className="text-sm text-gray-600">{flight.details}</p>
                                        </div>
                                        <div className="text-right flex flex-col items-end">
                                            <p className="font-bold text-orange-500">${flight.price}</p>
                                            {flight.link && !isFreeTier && (
                                                <Button 
                                                    size="sm" 
                                                    variant="outline"
                                                    className="mt-1 text-xs"
                                                    onClick={() => window.open(flight.link, '_blank')}
                                                >
                                                    <ExternalLink className="w-3 h-3 mr-1" />
                                                    Book
                                                </Button>
                                            )}
                                        </div>
                                    </div>
                                ))}
                                {isFreeTier && plan.flights.length > 1 && (
                                    <div className="text-center text-sm text-gray-500 italic">
                                        + {plan.flights.length - 1} more flight options available in Standard plan
                                    </div>
                                )}
                            </div>
                        </ResultCard>}
                        
                        {plan.accommodations && plan.accommodations.length > 0 && <ResultCard icon={Hotel} title="Accommodation" color="orange">
                           <div className="space-y-3">
                                {plan.accommodations?.slice(0, isFreeTier ? 1 : 3).map((acc, i) => (
                                    <div key={i} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                                        <div>
                                            <p className="font-semibold">{acc.name}</p>
                                            <p className="text-sm text-gray-600">{acc.details}</p>
                                        </div>
                                        <div className="text-right flex flex-col items-end">
                                            <p className="font-bold text-orange-500">${acc.price_per_night}/night <span className="text-xs font-normal">(est.)</span></p>
                                            {acc.link && !isFreeTier && (
                                                <Button 
                                                    size="sm" 
                                                    variant="outline"
                                                    className="mt-1 text-xs"
                                                    onClick={() => window.open(acc.link, '_blank')}
                                                >
                                                    <ExternalLink className="w-3 h-3 mr-1" />
                                                    Book
                                                </Button>
                                            )}
                                        </div>
                                    </div>
                                ))}
                                {isFreeTier && plan.accommodations.length > 1 && (
                                    <div className="text-center text-sm text-gray-500 italic">
                                        + {plan.accommodations.length - 1} more accommodation options in Standard plan
                                    </div>
                                )}
                            </div>
                        </ResultCard>}
                    </div>

                    <ResultCard icon={Calendar} title="Your Itinerary" color="lime">
                       <div className="space-y-6">
                            {/* For free users, show only first 2 days */}
                            {plan.daily_itinerary?.slice(0, isFreeTier ? 2 : plan.daily_itinerary.length).map((day, i) => (
                                <div key={i} className="border-l-4 border-teal-200 pl-4 py-2">
                                    <h4 className="font-bold text-lg mb-2">Day {day.day}: {day.title}</h4>
                                    {day.activities && typeof day.activities[0] === 'object' ? (
                                        <div className="space-y-4">
                                            {day.activities.map((activity, actIndex) => (
                                                <div key={actIndex} className="relative pl-6">
                                                    <div className="absolute left-0 top-1 h-full border-l-2 border-dashed border-gray-300"></div>
                                                    <div className="absolute left-[-5px] top-1.5 w-4 h-4 bg-teal-500 rounded-full border-2 border-white"></div>
                                                    <p className="font-semibold text-gray-800">{activity.time}: {activity.description}</p>
                                                    <p className="text-sm text-gray-600 pl-1">{activity.location_query}</p>
                                                    {activity.transport_to_next && (
                                                         <div className="mt-2 text-xs italic text-orange-600 pl-1">
                                                            → {activity.transport_to_next} to next activity
                                                         </div>
                                                    )}
                                                </div>
                                            ))}
                                        </div>
                                    ) : (
                                        <p className="text-sm text-gray-600">{Array.isArray(day.activities) ? day.activities.join(', ') : day.activities}</p>
                                    )}
                                </div>
                            ))}
                            {/* ALWAYS show upgrade prompt for free users with remaining days */}
                            {isFreeTier && plan.daily_itinerary && plan.daily_itinerary.length > 2 && (
                                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-4 rounded-lg text-center border-2 border-dashed border-blue-200">
                                    <Lock className="w-6 h-6 mx-auto text-blue-500 mb-2" />
                                    <p className="text-blue-700 font-semibold">Full {plan.daily_itinerary.length}-Day Itinerary Available</p>
                                    <p className="text-blue-600 text-sm">Upgrade to see all {plan.daily_itinerary.length - 2} remaining days</p>
                                </div>
                            )}
                        </div>
                    </ResultCard>

                    {isProTier && plan.premium_features?.enhanced_wallet && (
                        <EnhancedWalletCard walletData={plan.premium_features.enhanced_wallet} />
                    )}

                    <div className="text-center mt-6 space-y-6 non-printable">
                        {/* ALWAYS show upgrade section for free users */}
                        {isFreeTier && (
                            <div className="bg-gradient-to-br from-orange-50 to-red-50 border-2 border-orange-200 rounded-2xl p-4 sm:p-6">
                                <h3 className="text-xl font-bold text-orange-800 mb-3">Ready to unlock your full travel plan?</h3>
                                
                                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                                    {/* Standard Plan CTA */}
                                    <div className="bg-white rounded-xl p-4 shadow-md flex flex-col">
                                        <div className="flex items-center justify-center mb-2">
                                            <Zap className="w-5 h-5 text-orange-500 mr-2" />
                                            <h4 className="text-lg font-bold text-gray-800">Standard Plan</h4>
                                        </div>
                                        <p className="text-2xl font-bold text-orange-600 mb-2">$9.99 <span className="text-sm font-normal">per trip</span></p>
                                        <ul className="text-sm text-gray-700 space-y-1 mb-4 text-left px-2 flex-grow">
                                            <li>✅ Full editable itinerary</li>
                                            <li>✅ Save to dashboard for 3 months</li>
                                            <li>✅ Email/PDF delivery</li>
                                            <li>✅ All booking links</li>
                                        </ul>
                                        <Button 
                                            onClick={() => handleUpgrade('standard', plan.id)}
                                            disabled={isSaving}
                                            className="w-full py-3 sm:py-4 text-white font-bold rounded-xl text-lg shadow-lg hover:shadow-xl transform hover:scale-105"
                                            style={{ background: 'linear-gradient(135deg, #f67a24 0%, #d90102 100%)' }}
                                        >
                                            {isSaving ? (
                                                <div className="flex items-center justify-center">
                                                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                                                    Processing...
                                                </div>
                                            ) : "Get Full Plan"}
                                        </Button>
                                    </div>

                                    {/* Premium Plan Teaser */}
                                    <div className="bg-gradient-to-r from-purple-100 to-indigo-100 rounded-xl p-4 border border-purple-200 flex flex-col">
                                        <div className="flex items-center justify-center mb-2">
                                            <Crown className="w-5 h-5 text-purple-600 mr-2" />
                                            <h4 className="text-lg font-bold text-purple-800">Premium Plan</h4>
                                        </div>
                                         <ul className="text-xs text-purple-700 space-y-1 mb-4 text-left px-2 flex-grow">
                                            <li>✅ Everything in Standard</li>
                                            <li className="font-semibold">✨ Unlimited Trip Plans</li>
                                            <li className="font-semibold">🍲 Personalized Flavor Match</li>
                                            <li className="font-semibold">🌃 Curated Night Out Combos</li>
                                            <li className="font-semibold">📈 Live "Pulse Check" on crowds</li>
                                            <li className="font-semibold">💱 Enhanced Global Wallet</li>
                                            <li className="font-semibold">🔄 Offline Currency Converter</li>
                                        </ul>
                                        <div className="space-y-2 mt-auto">
                                            <Button 
                                                onClick={() => handleUpgrade('premium_monthly')}
                                                disabled={isSaving}
                                                className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-lg shadow-md"
                                            >
                                                {isSaving ? 'Processing...' : '$14.99 / month'}
                                            </Button>
                                            <Button 
                                                onClick={() => handleUpgrade('premium_yearly')}
                                                disabled={isSaving}
                                                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg shadow-md"
                                            >
                                                 {isSaving ? 'Processing...' : '$129.99 / year (Save 28%)'}
                                            </Button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}

                        {(isStandardTier || isProTier) && (
                            <div className="pt-6 border-t border-gray-200">
                                <h3 className="text-xl font-bold text-gray-700 mb-3 flex items-center justify-center">
                                    <Bot className="w-6 h-6 mr-2 text-blue-500" />
                                    Let's Chat! How Can I Improve Your Plan?
                                </h3>
                                <p className="text-sm text-gray-600 mb-2">Our AI is ready to help you perfect this itinerary. Tell me what you'd like to change or add.</p>
                                <p className="text-sm text-gray-500 mb-4">e.g., "On day 3, I want to see temples instead of beaches."</p>
                                <div className="max-w-xl mx-auto space-y-4">
                                    <Textarea 
                                        value={fineTunePrompt}
                                        onChange={(e) => setFineTunePrompt(e.target.value)}
                                        placeholder={getRestaurantSuggestion()}
                                        className="w-full p-4 border border-gray-200 rounded-2xl focus:border-[#A7AE23] resize-none h-20 shadow-sm"
                                    />
                                    <Button 
                                        onClick={() => {
                                            // Check if user added restaurant-related content
                                            const hasRestaurantRequest = fineTunePrompt.toLowerCase().includes('restaurant') || 
                                                                        fineTunePrompt.toLowerCase().includes('food') ||
                                                                        fineTunePrompt.toLowerCase().includes('eat') ||
                                                                        fineTunePrompt.toLowerCase().includes('dining');
                                            
                                            if (!hasFoodInRequest && hasRestaurantRequest) {
                                                // Show a brief success message about adding restaurants
                                                toast({
                                                    title: "Adding Restaurant Recommendations! 🍽️",
                                                    description: "I'm finding amazing local spots based on other travelers' experiences...",
                                                });
                                            }
                                            
                                            onFineTune(fineTunePrompt);
                                        }} 
                                        disabled={isGenerating}
                                        className="w-full bg-gradient-to-r from-teal-500 to-lime-500 text-white font-semibold"
                                    >
                                        {isGenerating ? (
                                            <>
                                                <MascotIcon width={20} height={20} className="mr-2 animate-spin" /> 
                                                Updating...
                                            </>
                                        ) : (
                                            <>
                                                <Wand2 className="w-5 h-5 mr-2" /> 
                                                Fine-Tune Plan
                                            </>
                                        )}
                                    </Button>
                                </div>
                            </div>
                        )}
                    </div>
                    
                    <div className="text-center text-xs text-gray-500 pt-6 border-t border-gray-200">
                        Our AI is not perfect but we do our best to deliver you the best results based on your desires. 😊
                    </div>
                </div>
            </div>
        </motion.div>
    );
}
