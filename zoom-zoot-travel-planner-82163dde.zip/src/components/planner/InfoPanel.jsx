import React from 'react';
import { Newspaper } from 'lucide-react';

const destinations = [
    { name: "Thailand", code: "TH" }, { name: "Vietnam", code: "VN" },
    { name: "Indonesia", code: "ID" }, { name: "Philippines", code: "PH" },
    { name: "Malaysia", code: "MY" }, { name: "Singapore", code: "SG" },
    { name: "Cambodia", code: "KH" }, { name: "Laos", code: "LA" },
];

const planningTips = [
    { emoji: "🌤️", title: "Best time:", text: "Nov-Mar (dry season)", color: "orange" },
    { emoji: "📋", title: "Visa:", text: "Requirements vary by country", color: "red" },
    { emoji: "💰", title: "Budget:", text: "$30-100+ per day", color: "lime" },
    { emoji: "🎒", title: "Packing:", text: "Pack light, buy local", color: "teal" },
];

const visaNewsLinks = [
    { name: "Thailand", url: "https://news.google.com/search?q=Thailand+visa+news" },
    { name: "Vietnam", url: "https://news.google.com/search?q=Vietnam+visa+news" },
    { name: "Indonesia", url: "https://news.google.com/search?q=Indonesia+visa+news" },
    { name: "Philippines", url: "https://news.google.com/search?q=Philippines+visa+news" },
    { name: "Malaysia", url: "https://news.google.com/search?q=Malaysia+visa+news" },
    { name: "Singapore", url: "https://news.google.com/search?q=Singapore+visa+news" },
    { name: "Cambodia", url: "https://news.google.com/search?q=Cambodia+visa+news" },
    { name: "Laos", url: "https://news.google.com/search?q=Laos+visa+news" },
];

export default function InfoPanel({ onSelectCountry, mobileView = null }) {
    // Mobile Visa News view - ONLY show visa news
    if (mobileView === 'visa') {
        return (
            <div className="glass-effect rounded-3xl p-6 phone-tray floating-animation" style={{ animationDelay: '0.5s' }}>
                <div className="text-center mb-6">
                    <h2 className="text-xl font-bold text-[#297479] mb-2">Latest Visa News</h2>
                    <div className="w-12 h-1 bg-gradient-to-r from-red-500 to-[#297479] mx-auto rounded-full"></div>
                </div>
                
                <div className="space-y-2">
                    {visaNewsLinks.map(link => (
                        <a 
                            key={link.name} 
                            href={link.url} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="flex items-center p-3 rounded-lg bg-gray-100 hover:bg-gray-200 transition-colors"
                        >
                            <Newspaper className="w-4 h-4 mr-3 text-gray-600"/>
                            <span className="font-semibold text-sm text-gray-800">{link.name} Visa Updates</span>
                        </a>
                    ))}
                </div>
            </div>
        );
    }

    // Mobile Explore view - ONLY destinations and planning tips, NO visa news
    if (mobileView === 'explore') {
        return (
            <div className="glass-effect rounded-3xl p-6 phone-tray floating-animation" style={{ animationDelay: '0.5s' }}>
                <div className="text-center mb-6">
                    <h2 className="text-xl font-bold text-[#297479] mb-2">Explore Southeast Asia</h2>
                    <div className="w-12 h-1 bg-gradient-to-r from-red-500 to-[#297479] mx-auto rounded-full"></div>
                </div>
                
                <div className="mb-6">
                    <h3 className="font-bold mb-4 section-title text-lg">🌏 Popular Destinations</h3>
                    <div className="grid grid-cols-2 gap-3">
                        {destinations.map(dest => (
                            <button key={dest.code} onClick={() => onSelectCountry(dest.name)} className="country-btn p-4 rounded-2xl text-sm font-semibold shadow-sm hover:shadow-lg">
                                {dest.name} <span className="text-xs opacity-70">{dest.code}</span>
                            </button>
                        ))}
                    </div>
                </div>

                <div>
                    <h3 className="font-bold mb-4 section-title text-lg">💡 Planning Tips</h3>
                    <div className="space-y-4">
                        {planningTips.map(tip => (
                            <div key={tip.title} className={`bg-gradient-to-r from-${tip.color}-500/10 to-${tip.color}-500/5 p-4 rounded-2xl border-l-4 border-${tip.color}-500`}>
                                <div className="flex items-center">
                                    <span className={`text-${tip.color}-500 mr-3 text-xl`}>{tip.emoji}</span>
                                    <div>
                                        <span className="font-bold text-gray-800">{tip.title}</span>
                                        <span className="text-gray-600 ml-1">{tip.text}</span>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        );
    }

    // Desktop version - keep everything as is (destinations, tips, AND visa news)
    return (
        <div className="glass-effect rounded-3xl p-6 phone-tray floating-animation" style={{ animationDelay: '0.5s' }}>
            <div className="text-center mb-6">
                <h2 className="text-xl font-bold text-[#297479] mb-2">Explore Southeast Asia</h2>
                <div className="w-12 h-1 bg-gradient-to-r from-red-500 to-[#297479] mx-auto rounded-full"></div>
            </div>
            
            <div className="mb-6">
                <h3 className="font-bold mb-4 section-title text-lg">🌏 Popular Destinations</h3>
                <div className="grid grid-cols-2 gap-3">
                    {destinations.map(dest => (
                        <button key={dest.code} onClick={() => onSelectCountry(dest.name)} className="country-btn p-4 rounded-2xl text-sm font-semibold shadow-sm hover:shadow-lg">
                            {dest.name} <span className="text-xs opacity-70">{dest.code}</span>
                        </button>
                    ))}
                </div>
            </div>

            <div className="mb-6">
                <h3 className="font-bold mb-4 section-title text-lg">💡 Planning Tips</h3>
                <div className="space-y-4">
                    {planningTips.map(tip => (
                        <div key={tip.title} className={`bg-gradient-to-r from-${tip.color}-500/10 to-${tip.color}-500/5 p-4 rounded-2xl border-l-4 border-${tip.color}-500`}>
                            <div className="flex items-center">
                                <span className={`text-${tip.color}-500 mr-3 text-xl`}>{tip.emoji}</span>
                                <div>
                                    <span className="font-bold text-gray-800">{tip.title}</span>
                                    <span className="text-gray-600 ml-1">{tip.text}</span>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
            
            <div>
                <h3 className="font-bold mb-4 section-title text-lg">📰 Latest Visa News</h3>
                <div className="space-y-2">
                    {visaNewsLinks.map(link => (
                        <a 
                            key={link.name} 
                            href={link.url} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="flex items-center p-3 rounded-lg bg-gray-100 hover:bg-gray-200 transition-colors"
                        >
                            <Newspaper className="w-4 h-4 mr-3 text-gray-600"/>
                            <span className="font-semibold text-sm text-gray-800">{link.name} Visa Updates</span>
                        </a>
                    ))}
                </div>
            </div>
        </div>
    );
}