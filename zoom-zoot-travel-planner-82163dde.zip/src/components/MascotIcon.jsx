import React from 'react';

export default function MascotIcon({ width = 24, height = 24, className = "" }) {
  return (
    <img 
      src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/689cad7ad0f4e84e82163dde/a9b8934b4_ZoomZootFavicon.png" 
      alt="ZoomZoot Mascot" 
      width={width} 
      height={height}
      className={className}
    />
  );
}