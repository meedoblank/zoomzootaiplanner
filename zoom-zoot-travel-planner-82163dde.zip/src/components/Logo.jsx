import React from 'react';

export default function Logo({ width = 45, height = 45, showText = true, className = "" }) {
  const textSize = width > 40 ? "text-xl sm:text-2xl" : "text-lg";
  const dashSizes = width > 40 ? { large: "w-6", medium: "w-4", small: "w-5" } : { large: "w-5", medium: "w-3", small: "w-4" };
  
  return (
    <div className={`flex items-center space-x-2 ${className}`}>
      {/* Mascot Image */}
      <div className="flex-shrink-0">
         <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/689cad7ad0f4e84e82163dde/a9b8934b4_ZoomZootFavicon.png" 
            alt="ZoomZoot Logo" 
            width={width} 
            height={height}
          />
      </div>
      
      {/* Company Name and Dashes */}
      {showText && (
        <div className="text-left">
          <h1 className={`font-bold font-['Fredoka_One'] leading-tight ${textSize}`}>
            <span style={{ color: '#297479' }}>Zoom</span>
            <span style={{ color: '#d90102' }}>Zoot</span>
          </h1>
          <div className="flex items-center justify-center space-x-1 mt-1">
            <div className={`${dashSizes.large} h-1 rounded`} style={{ backgroundColor: '#f67a24' }}></div>
            <div className={`${dashSizes.medium} h-1 rounded`} style={{ backgroundColor: '#aab624' }}></div>
            <div className={`${dashSizes.small} h-1 rounded`} style={{ backgroundColor: '#dded27' }}></div>
          </div>
        </div>
      )}
    </div>
  );
}