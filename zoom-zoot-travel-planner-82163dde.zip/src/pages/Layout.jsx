

import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import Logo from "./components/Logo";
import { Button } from "@/components/ui/button";
import { Plane, Compass, Home, Calculator } from "lucide-react";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();

  const scriptContent = `
    // Disable right-click context menu
    document.addEventListener('contextmenu', function(e) {
      e.preventDefault();
      return false;
    });
    
    // Disable common screenshot shortcuts
    document.addEventListener('keydown', function(e) {
      // Disable F12, Ctrl+Shift+I, Ctrl+Shift+C, Ctrl+U
      if (e.key === 'F12' || 
          (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'C')) ||
          (e.ctrlKey && e.key === 'U') ||
          (e.ctrlKey && e.shiftKey && e.key === 'K') ||
          (e.metaKey && e.altKey && e.key === 'I')) {
        e.preventDefault();
        return false;
      }
      
      // Disable Print Screen
      if (e.key === 'PrintScreen') {
        e.preventDefault();
        return false;
      }
    });
    
    // Disable drag and drop (covers image saving as well)
    document.addEventListener('dragstart', function(e) {
      e.preventDefault();
      return false;
    });
    
    // Hide Base44 clone button
    document.addEventListener('DOMContentLoaded', function() {
      const hideBase44Button = () => {
        const button = document.querySelector('[data-testid="clone-button"], .clone-button, [aria-label*="clone"], [title*="clone"]');
        if (button) {
          button.style.display = 'none';
        }
      };
      
      hideBase44Button();
      // Check periodically in case it loads later
      setInterval(hideBase44Button, 1000);
    });
  `;

  return (
    <div className="bg-gradient-to-br from-[#297479] via-[#aab624] to-[#f67a24] min-h-screen font-['Ubuntu',_sans-serif]" style={{userSelect: 'none', WebkitUserSelect: 'none', MozUserSelect: 'none', msUserSelect: 'none'}}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Fredoka+One:wght@400&family=Poppins:wght@400;600;700&family=Jost:wght@300;900&family=Libre+Baskerville:ital@1&family=Ubuntu:wght@300;400;500;700&display=swap');
        
        /* Disable text selection and context menu */
        * {
          -webkit-user-select: none;
          -moz-user-select: none;
          -ms-user-select: none;
          user-select: none;
          -webkit-touch-callout: none;
          -webkit-tap-highlight-color: transparent;
        }
        
        /* Disable right-click context menu */
        body {
          -webkit-touch-callout: none;
          -webkit-user-select: none;
          -khtml-user-select: none;
          -moz-user-select: none;
          -ms-user-select: none;
          user-select: none;
        }
        
        /* Disable screenshot on mobile devices */
        @media screen and (-webkit-min-device-pixel-ratio: 0) {
          body {
            -webkit-app-region: no-drag;
            -webkit-user-select: none;
          }
        }
        
        /* Disable drag and drop */
        * {
          -webkit-user-drag: none;
          -khtml-user-drag: none;
          -moz-user-drag: none;
          -o-user-drag: none;
          user-drag: none;
        }
        
        img {
          -webkit-user-drag: none;
          -khtml-user-drag: none;
          -moz-user-drag: none;
          -o-user-drag: none;
          user-drag: none;
          pointer-events: none;
        }

        .hover-lift {
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .hover-lift:hover {
            transform: translateY(-4px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
        }
        .glass-effect {
            backdrop-filter: blur(15px);
            background: rgba(255, 255, 255, 0.98);
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        }
        .phone-tray {
            width: 100%;
            max-width: 420px;
            height: auto;
            min-height: calc(100vh - 140px);
            overflow-y: auto;
            scrollbar-width: thin;
            scrollbar-color: #297479 transparent;
            margin: 0 auto;
        }
        .phone-tray::-webkit-scrollbar { width: 4px; }
        .phone-tray::-webkit-scrollbar-track { background: transparent; }
        .phone-tray::-webkit-scrollbar-thumb { background: #297479; border-radius: 2px; }
        @media (min-width: 1024px) { 
            .phone-tray { 
                margin: 0; 
                height: auto;
                min-height: calc(100vh - 140px);
            } 
        }
        
        .popular-request {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            border: 1px solid rgba(41, 116, 121, 0.1);
            transition: all 0.3s ease;
        }
        .popular-request:hover {
            background: linear-gradient(135deg, #297479 0%, #aab624 100%);
            color: white;
            transform: translateX(8px);
        }
        .country-btn {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            border: 2px solid rgba(41, 116, 121, 0.1);
            transition: all 0.3s ease;
        }
        .country-btn:hover {
            background: linear-gradient(135deg, #297479 0%, #aab624 100%);
            border-color: #297479;
            color: white;
            transform: scale(1.05);
        }
        .trip-idea {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            border: 1px solid rgba(246, 122, 36, 0.1);
            transition: all 0.3s ease;
        }
        .trip-idea:hover {
            background: linear-gradient(135deg, #f67a24 0%, #d90102 100%);
            color: white;
            transform: translateX(8px);
        }
        .floating-animation { animation: float 6s ease-in-out infinite; }
        @keyframes float { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-10px); } }
        
        .pulse-glow { animation: pulse-glow 2s ease-in-out infinite alternate; }
        @keyframes pulse-glow {
            from { box-shadow: 0 0 20px rgba(217, 1, 2, 0.3); }
            to { box-shadow: 0 0 30px rgba(217, 1, 2, 0.6); }
        }
        
        .mascot-pulse { animation: mascot-pulse 2s ease-in-out infinite; }
        @keyframes mascot-pulse {
            0%, 100% { 
                transform: scale(1);
                filter: drop-shadow(0 0 8px rgba(221, 237, 39, 0.4));
            }
            50% { 
                transform: scale(1.05);
                filter: drop-shadow(0 0 20px rgba(221, 237, 39, 0.8)) drop-shadow(0 0 35px rgba(221, 237, 39, 0.6));
            }
        }
        
        .section-title {
            background: linear-gradient(135deg, #f67a24 0%, #d90102 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            font-weight: 800;
        }
        
        .country-card {
            transition: all 0.3s ease;
            cursor: pointer;
            border: 1px solid transparent;
        }
        .country-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        .country-card.selected {
            border: 1px solid #297479 !important;
            background: linear-gradient(45deg, rgba(41, 116, 121, 0.15), rgba(170, 182, 36, 0.15)) !important;
            transform: scale(1.02);
            box-shadow: 0 8px 25px rgba(41, 116, 121, 0.3);
        }
        .dashboard-card {
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .dashboard-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        
        @media print {
          body, html {
            background: #fff;
            color: #000;
          }
          .non-printable {
            display: none !important;
          }
          .printable-container {
            display: block !important;
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            padding: 20px;
            box-shadow: none;
            border: none;
            backdrop-filter: none;
            background: #fff;
          }
          .printable-card {
             background: #f9fafb !important;
             border: 1px solid #e5e7eb !important;
             box-shadow: none !important;
          }
           .printable-title {
            color: #1f2937 !important;
          }
        }
        
        /* Mobile navigation improvements */
        @media (max-width: 640px) {
          .mobile-nav {
            padding: 0.5rem 0.75rem;
          }
          .mobile-nav .nav-button {
            min-width: 36px;
            height: 32px;
            padding: 0.25rem;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            gap: 1px;
          }
          .mobile-nav .nav-text {
            font-size: 0.5rem;
            line-height: 1;
          }
        }
      `}</style>

      <header className="glass-effect border-b border-white/20 sticky top-0 z-50 non-printable">
        <div className="max-w-7xl mx-auto px-2 sm:px-6 py-2 sm:py-3 mobile-nav">
          <div className="flex items-center justify-between">
            <Link to={createPageUrl("Dashboard")} className="flex-shrink-0">
              <Logo width={40} height={40} showText={true} />
            </Link>
            <div className="flex items-center space-x-1 sm:space-x-2">
              <Button 
                asChild 
                variant={location.pathname === createPageUrl("Dashboard") ? "default" : "outline"} 
                size="sm"
                className="bg-[#297479] hover:bg-[#297479]/90 text-white nav-button"
              >
                <Link to={createPageUrl("Dashboard")}>
                  <Home className="w-3 h-3 sm:w-4 sm:h-4" />
                  <span className="nav-text hidden sm:inline text-xs sm:ml-2">Home</span>
                </Link>
              </Button>
              <Button 
                asChild 
                variant={location.pathname === createPageUrl("Planner") ? "default" : "outline"} 
                size="sm"
                className="bg-[#D2251B] hover:bg-[#D2251B]/90 text-white nav-button"
              >
                <Link to={createPageUrl("Planner")}>
                  <Compass className="w-3 h-3 sm:w-4 sm:h-4" />
                  <span className="nav-text hidden sm:inline text-xs sm:ml-2">Explore</span>
                </Link>
              </Button>
              <Button 
                asChild 
                variant={location.pathname === createPageUrl("MyTrips") ? "default" : "outline"} 
                size="sm"
                className="bg-[#f67a24] hover:bg-[#f67a24]/90 text-white nav-button"
              >
                <Link to={createPageUrl("MyTrips")}>
                  <Plane className="w-3 h-3 sm:w-4 sm:h-4" />
                  <span className="nav-text hidden sm:inline text-xs sm:ml-2">Trips</span>
                </Link>
              </Button>
              <Button 
                asChild 
                variant={location.pathname === createPageUrl("CurrencyConverter") ? "default" : "outline"} 
                size="sm"
                className="bg-[#aab624] hover:bg-[#aab624]/90 text-white nav-button"
              >
                <Link to={createPageUrl("CurrencyConverter")}>
                  <Calculator className="w-3 h-3 sm:w-4 sm:h-4" />
                  <span className="nav-text hidden sm:inline text-xs sm:ml-2">Currency EX</span>
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main>{children}</main>
      <script dangerouslySetInnerHTML={{ __html: scriptContent }} />
    </div>
  );
}

