
import React, { useState, useEffect, useCallback } from 'react';
import { User } from '@/api/entities';
import { Itinerary } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, PlusCircle, Bookmark, Settings, Calendar, Users, Clock, Plane } from 'lucide-react';
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/components/ui/use-toast";
import { Toaster } from "@/components/ui/toaster";
import { MascotIcon } from "@/components/MascotIcon";

const popularDestinations = [
    { name: "Thailand", emoji: "🇹🇭", trips: 1247 },
    { name: "Vietnam", emoji: "🇻🇳", trips: 892 },
    { name: "Indonesia", emoji: "🇮🇩", trips: 1156 },
    { name: "Philippines", emoji: "🇵🇭", trips: 678 },
    { name: "Singapore", emoji: "🇸🇬", trips: 567 },
    { name: "Malaysia", emoji: "🇲🇾", trips: 789 }
];

export default function DashboardPage() {
    const [user, setUser] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [recentTrips, setRecentTrips] = useState([]);
    const [stats, setStats] = useState({ trips: 0, countries: 0, days: 0 });
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const { toast } = useToast();

    const loadUserData = useCallback(async () => {
        setIsLoading(true);
        try {
            const currentUser = await User.me();
            setUser(currentUser);
            setIsAuthenticated(true);
            
            const userTrips = await Itinerary.filter({ created_by: currentUser.email });
            setStats(prevStats => ({ ...prevStats, trips: userTrips.length }));

            // Get recent trips from user data or extract from recent itineraries
            if (currentUser.recent_trips && currentUser.recent_trips.length > 0) {
                setRecentTrips(currentUser.recent_trips.slice(0, 2));
            } else if (userTrips.length > 0) {
                // Extract destinations from recent trips
                const extractedRecentTrips = userTrips
                    .sort((a, b) => new Date(b.created_date) - new Date(a.created_date)) // Sort by most recent
                    .slice(0, 2)
                    .map(trip => ({
                        destination: trip.title.split(' ')[0] || 'Recent Trip', // Assuming destination is first word of title
                        trip_date: trip.created_date, // Use full date for date formatting
                        title: trip.title
                    }));
                setRecentTrips(extractedRecentTrips);
            }
        } catch (error) {
            console.log("User not authenticated:", error);
            setIsAuthenticated(false);
        }
        setIsLoading(false);
    }, []); // Removed 'toast' from dependency array as it's no longer used in the catch block here

    useEffect(() => {
        loadUserData();
    }, [loadUserData]);

    if (isLoading) {
        return (
            <>
                <Toaster /> {/* Toaster is placed here to be available even during loading state */}
                <div className="max-w-md mx-auto p-6 space-y-4">
                    <div className="animate-pulse space-y-4">
                        <div className="h-4 bg-gray-300 rounded w-3/4"></div>
                        <div className="h-20 bg-gray-300 rounded"></div>
                        <div className="h-32 bg-gray-300 rounded"></div>
                    </div>
                </div>
            </>
        );
    }

    if (!isAuthenticated) {
        return (
            <>
                <Toaster /> {/* Toaster is placed here for the unauthenticated state */}
                <div className="max-w-md mx-auto p-6 pt-16 sm:pt-28">
                    <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="text-center glass-effect rounded-2xl p-8"
                    >
                        <div className="inline-block mb-4 p-2 rounded-full">
                            <MascotIcon width={80} height={80} />
                        </div>
                        <h1 className="text-3xl font-bold text-white mb-4">Welcome to ZoomZoot!</h1>
                        <p className="text-white/90 mb-6">Please log in to access your personalized travel dashboard and start planning your Southeast Asia adventure.</p>
                        <Button 
                            onClick={() => User.login()}
                            className="bg-gradient-to-r from-[#297479] to-[#aab624] text-white font-semibold py-3 px-6 rounded-xl"
                        >
                            Log In to Get Started
                        </Button>
                    </motion.div>
                </div>
            </>
        );
    }

    return (
        <>
            <Toaster /> {/* Toaster is placed here for the authenticated state */}
            <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6 sm:space-y-8 pt-16 sm:pt-28">
                {/* Welcome Header */}
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center"
                >
                    <div className="inline-block mb-4 mascot-pulse p-2 rounded-full">
                        <MascotIcon width={80} height={80} />
                    </div>
                    <h1 className="text-4xl font-bold text-white">Welcome, {user?.full_name?.split(' ')[0] || 'Explorer'}!</h1>
                    <p className="text-white/90 mt-2 text-lg">Your next adventure is just a click away.</p>
                    {/* Add subscription status display */}
                    <div className="mt-3">
                        <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-semibold bg-white/20 text-white">
                            {user?.subscription_type === 'premium' && '👑 Premium Member'}
                            {user?.subscription_type === 'standard' && '⭐ Standard Member'}
                            {(!user?.subscription_type || user?.subscription_type === 'free') && '🌟 Free Member'}
                        </span>
                    </div>
                </motion.div>

                {/* Quick Stats */}
                <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 }}
                    className="grid grid-cols-2 gap-4 mb-6"
                >
                    <Card className="text-center dashboard-card" style={{ border: '1px solid #f67a24' }}>
                        <CardContent className="p-4">
                            <div className="text-2xl font-bold" style={{ color: '#f67a24' }}>{stats.trips}</div>
                            <p className="text-sm text-gray-600">Saved Trips</p>
                        </CardContent>
                    </Card>
                    <Card className="text-center dashboard-card" style={{ border: '1px solid #aab624' }}>
                        <CardContent className="p-4">
                            <div className="text-2xl font-bold" style={{ color: '#aab624' }}>8</div>
                            <p className="text-sm text-gray-600">Countries</p>
                        </CardContent>
                    </Card>
                </motion.div>

                {/* Quick Actions */}
                <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="space-y-3 mb-6"
                >
                    <Button asChild className="w-full h-14 text-lg font-semibold" style={{ background: 'linear-gradient(135deg, #297479 0%, #aab624 100%)', color: 'white' }}>
                        <Link to={createPageUrl("Planner")}>
                            <PlusCircle className="w-5 h-5 mr-3" />
                            Plan New Trip
                        </Link>
                    </Button>
                    
                    <Button asChild variant="outline" className="w-full h-12 border-2" style={{ borderColor: '#f67a24', color: '#f67a24' }}>
                        <Link to={createPageUrl("MyTrips")}>
                            <Bookmark className="w-4 h-4 mr-2" />
                            View Saved Trips
                        </Link>
                    </Button>
                </motion.div>

                {/* Recent Trips Section */}
                {recentTrips.length > 0 && (
                    <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.25 }}
                        className="mb-6"
                    >
                        <h3 className="text-lg font-bold mb-4 text-white">🕒 Your Recent Destinations</h3>
                        <div className="space-y-2">
                            {recentTrips.map((trip, index) => (
                                <Card key={index} className="country-card text-left cursor-pointer hover:shadow-lg transition-all">
                                    <CardContent className="p-3">
                                        <p className="text-sm font-semibold text-[#297479]">{trip.destination}</p>
                                        <p className="text-xs text-gray-500">Planned: {new Date(trip.trip_date).toLocaleDateString()}</p>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    </motion.div>
                )}

                {/* Popular Destinations */}
                <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="mb-6"
                >
                    <h3 className="text-lg font-bold mb-4 text-white">🌏 Popular Destinations</h3>
                    <div className="grid grid-cols-3 gap-3">
                        {popularDestinations.map((destination, index) => (
                            <Card key={destination.name} className="country-card text-center cursor-pointer hover:shadow-lg transition-all">
                                <CardContent className="p-3">
                                    <div className="text-2xl mb-1">{destination.emoji}</div>
                                    <p className="text-xs font-semibold">{destination.name}</p>
                                    <p className="text-xs text-gray-500">{destination.trips} trips</p>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </motion.div>

                {/* Travel Inspiration */}
                <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                    className="mb-6"
                >
                    <h3 className="text-lg font-bold mb-4 text-white">✨ Travel Inspiration</h3>
                    <div className="space-y-3">
                        <Card className="dashboard-card" style={{ background: 'linear-gradient(135deg, rgba(41,116,121,0.1) 0%, rgba(170,182,36,0.1) 100%)' }}>
                            <CardContent className="p-4">
                                <h4 className="font-semibold text-white">🏝️ Island Hopping in Philippines</h4>
                                <p className="text-sm text-white/80 mt-1">Explore pristine beaches and crystal-clear waters</p>
                            </CardContent>
                        </Card>
                        
                        <Card className="dashboard-card" style={{ background: 'linear-gradient(135deg, rgba(246,122,36,0.1) 0%, rgba(217,1,2,0.1) 100%)' }}>
                            <CardContent className="p-4">
                                <h4 className="font-semibold text-white">🏛️ Cultural Journey in Cambodia</h4>
                                <p className="text-sm text-white/80 mt-1">Discover ancient temples and rich history</p>
                            </CardContent>
                        </Card>
                    </div>
                </motion.div>

                {/* Settings Link */}
                <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 }}
                    className="text-center"
                >
                    <Button asChild variant="ghost" className="text-white/90 hover:text-white hover:bg-white/20">
                        <Link to={createPageUrl("Settings")}>
                            <Settings className="w-4 h-4 mr-2" />
                            Settings & Account
                        </Link>
                    </Button>
                </motion.div>
            </div>
        </>
    );
}
