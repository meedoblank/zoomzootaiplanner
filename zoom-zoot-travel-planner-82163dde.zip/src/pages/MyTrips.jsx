
import React, { useState, useEffect, useCallback } from 'react';
import { Itinerary } from '@/api/entities';
import { User } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar, DollarSign, MapPin, Trash2, Mail, PlusCircle, CheckCircle, AlertCircle } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { useToast } from "@/components/ui/use-toast";
import { Toaster } from "@/components/ui/toaster";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion, AnimatePresence } from "framer-motion";
import { SendEmail } from '@/api/integrations';
import TripViewer from '../components/trips/TripViewer';

export default function MyTripsPage() {
    const [trips, setTrips] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [viewingTrip, setViewingTrip] = useState(null);
    const { toast } = useToast();

    const loadTrips = useCallback(async () => {
        setIsLoading(true);
        try {
            const user = await User.me();
            setIsAuthenticated(true);
            // Sort by created_date in descending order to get the most recent trip first
            const userTrips = await Itinerary.filter({ created_by: user.email }, '-created_date');
            setTrips(userTrips);
        } catch (error) {
            console.log("User not authenticated:", error);
            setIsAuthenticated(false);
        }
        setIsLoading(false);
    }, []);

    useEffect(() => {
        loadTrips();
    }, [loadTrips]);

    const canViewTrip = (trip) => {
        if (!trip.created_date) {
            return false; // Cannot determine viewability without a creation date
        }
        const tripDate = new Date(trip.created_date);
        const threeMonthsAgo = new Date();
        threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);
        return tripDate > threeMonthsAgo;
    };

    const getMostRecentTrip = () => {
        if (trips.length === 0) return null;
        return trips[0]; // Already sorted by -created_date in loadTrips
    };

    const handleViewTrip = (trip) => {
        if (!canViewTrip(trip)) {
            toast({
                variant: "destructive",
                title: "Trip Expired",
                description: "This trip is older than 3 months. Please refer to your email for the full details.",
            });
            return;
        }
        // Set the trip to be viewed in the TripViewer component
        setViewingTrip(trip);
    };

    const handleEmailTrip = async (trip) => {
        try {
            const user = await User.me();
            if (!user.email) {
                throw new Error("User not found or missing email.");
            }
            
            toast({
                title: "Sending Email...",
                description: `Your plan for "${trip.title}" is on its way.`,
            });
            
            const plan = trip.generated_plan;
            if (!plan) {
                throw new Error("Generated plan not available for this trip.");
            }

            const dailyItineraryHtml = plan.daily_itinerary && plan.daily_itinerary.length > 0
                ? plan.daily_itinerary.map(day => `
                    <div style="margin-bottom: 15px;">
                        <h3 style="color: #297479;">Day ${day.day || 'N/A'}: ${day.title || 'N/A'}</h3>
                        ${(day.activities && Array.isArray(day.activities))
                            ? day.activities.map(activity => `
                                <div style="padding-left: 15px; border-left: 2px solid #eee; margin-bottom: 8px;">
                                    <p style="margin: 0;"><strong>${activity.time || ''}:</strong> ${activity.description || ''}</p>
                                    ${activity.transport_to_next ? `<p style="margin: 2px 0 0 0; color: #f67a24; font-size: 0.9em; font-style: italic;">&rarr; ${activity.transport_to_next}</p>` : ''}
                                </div>
                            `).join('')
                            : '<p>No activities listed for this day.</p>'
                        }
                    </div>
                `).join('')
                : '<p>No daily itinerary available for this plan.</p>';
            
            const flightsHtml = plan.flights && plan.flights.length > 0
                ? plan.flights.map(f => `<div style="margin-bottom: 10px;"><strong>${f.airline || 'N/A'}</strong>: ${f.details || 'N/A'} - $${f.price || 'N/A'} <a href="${f.link || '#'}" target="_blank">Book Here</a></div>`).join('')
                : '<p>No specific flights in this plan.</p>';

            const accommodationsHtml = plan.accommodations && plan.accommodations.length > 0
                ? plan.accommodations.map(a => `<div style="margin-bottom: 10px;"><strong>${a.name || 'N/A'}</strong>: ${a.details || 'N/A'} - $${a.price_per_night || 'N/A'}/night USD <a href="${a.link || '#'}" target="_blank">Book Here</a></div>`).join('')
                : '<p>No specific accommodations in this plan.</p>';

            const emailBody = `
                <div style="font-family: sans-serif; line-height: 1.6;">
                    <h1>Your ZoomZoot Travel Plan: ${trip.title || 'N/A'}</h1>
                    <p>Based on your request: "<em>${trip.request_description || 'N/A'}</em>"</p>
                    <hr>
                    <h2>Summary</h2>
                    <p>${plan.summary || 'N/A'}</p>
                    <hr>
                    <h2>Flight Options</h2>
                    ${flightsHtml}
                    <hr>
                    <h2>Accommodation Suggestions</h2>
                    ${accommodationsHtml}
                    <hr>
                    <h2>Daily Itinerary</h2>
                    ${dailyItineraryHtml}
                    <hr>
                    <br/><p>Happy travels!</p><p>The ZoomZoot Team</p>
                </div>
            `;

            await SendEmail({
                to: user.email,
                subject: `Your Saved Travel Plan: ${trip.title}`,
                body: emailBody,
            });
            
            toast({
                title: ( <div className="flex items-center"><CheckCircle className="mr-2 text-green-500" /> Email Sent!</div> ),
                description: "Check your inbox for the full itinerary.",
            });

        } catch (error) {
             console.error("Failed to send email:", error);
             toast({
                variant: "destructive",
                title: ( <div className="flex items-center"><AlertCircle className="mr-2" /> Email Failed</div> ),
                description: "Could not send the email. Please try again.",
            });
        }
    };

    const handleDelete = async (tripId) => {
        try {
            await Itinerary.delete(tripId);
            toast({
                title: "Trip Deleted",
                description: "Your itinerary has been removed."
            });
            loadTrips(); // Refresh the list
        } catch (error) {
            console.error("Failed to delete trip:", error);
             toast({
                variant: "destructive",
                title: "Error",
                description: "Could not delete the trip. Please try again."
            });
        }
    };
    
    if (isLoading) {
        return (
            <div className="max-w-5xl mx-auto px-4 py-8 pt-24 sm:pt-28">
                <h1 className="text-4xl font-bold text-white mb-8">My Saved Trips</h1>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {[...Array(3)].map((_, i) => (
                        <Card key={i} className="bg-white/90">
                            <CardHeader><Skeleton className="h-6 w-3/4" /></CardHeader>
                            <CardContent className="space-y-4">
                                <Skeleton className="h-4 w-full" />
                                <Skeleton className="h-4 w-1/2" />
                            </CardContent>
                            <CardFooter><Skeleton className="h-10 w-full" /></CardFooter>
                        </Card>
                    ))}
                </div>
            </div>
        );
    }

    // Show login prompt for unauthenticated users
    if (!isAuthenticated) {
        return (
            <div className="max-w-5xl mx-auto px-4 py-8 pt-16 sm:pt-28">
                <Toaster />
                <h1 className="text-4xl font-bold text-white mb-8">My Saved Trips</h1>
                <div className="text-center glass-effect rounded-2xl p-12">
                    <h2 className="text-2xl font-bold text-[#297479] mb-4">Please Log In</h2>
                    <p className="text-gray-600 mb-6">You need to be logged in to view your saved trips.</p>
                    <Button 
                        onClick={() => User.login()}
                        className="bg-[#297479] hover:bg-[#297479]/90 text-white"
                    >
                        Log In
                    </Button>
                </div>
            </div>
        );
    }

    const mostRecentTrip = getMostRecentTrip();

    return (
        <>
        <Toaster />
        <div className="max-w-5xl mx-auto px-4 py-8 pt-16 sm:pt-28">
            <h1 className="text-4xl font-bold text-white mb-4">My Saved Trips</h1>
            
            {/* Access Notice */}
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
                <div className="flex items-start">
                    <Calendar className="w-5 h-5 text-yellow-600 mt-0.5 mr-3 flex-shrink-0" />
                    <div className="text-sm text-yellow-800">
                        <p className="font-semibold mb-1">Trip Access Policy</p>
                        <p>Trip details are viewable for 3 months after creation. After that, refer to your email copy.</p>
                    </div>
                </div>
            </div>

            {/* Most Recent Trip Spotlight */}
            {mostRecentTrip && canViewTrip(mostRecentTrip) && (
                <div className="mb-8">
                    <h2 className="text-2xl font-bold text-white mb-4">📍 Most Recent Trip</h2>
                    <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="glass-effect rounded-2xl p-6 border-2 border-yellow-300"
                    >
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                            <div className="lg:col-span-2">
                                <h3 className="text-2xl font-bold text-[#297479] mb-2">{mostRecentTrip.title || 'Untitled Trip'}</h3>
                                <p className="text-gray-700 mb-4">
                                    {mostRecentTrip.request_description 
                                        ? `${mostRecentTrip.request_description.substring(0, 100)}${mostRecentTrip.request_description.length > 100 ? '...' : ''}` 
                                        : 'No description provided.'}
                                </p>
                                <div className="flex flex-wrap gap-4 text-sm">
                                    <div className="flex items-center"><Calendar className="w-4 h-4 mr-2 text-orange-500" /> {mostRecentTrip.duration ? `${mostRecentTrip.duration} days` : 'N/A'}</div>
                                    <div className="flex items-center"><DollarSign className="w-4 h-4 mr-2 text-lime-500" /> {mostRecentTrip.budget || 'N/A'}</div>
                                    <div className="flex items-center"><MapPin className="w-4 h-4 mr-2 text-red-500" /> {mostRecentTrip.travel_style || 'N/A'}</div>
                                </div>
                            </div>
                            <div className="flex flex-col justify-center space-y-3">
                                <Button onClick={() => handleViewTrip(mostRecentTrip)} className="bg-[#297479] hover:bg-[#297479]/90 text-white">
                                    View Trip
                                </Button>
                            </div>
                        </div>
                    </motion.div>
                </div>
            )}

            {trips.length === 0 ? (
                <div className="text-center glass-effect rounded-2xl p-12">
                     <h2 className="text-2xl font-bold text-[#297479]">No Trips Yet!</h2>
                     <p className="text-gray-600 mt-2 mb-6">You haven't saved any travel plans. Let's create one!</p>
                     <Button asChild size="lg" className="bg-[#f67a24] hover:bg-[#f67a24]/90 text-white">
                        <Link to={createPageUrl("Planner")}>
                            <PlusCircle className="w-5 h-5 mr-2"/> Plan a New Trip
                        </Link>
                     </Button>
                </div>
            ) : (
                <div>
                    <h2 className="text-2xl font-bold text-white mb-6">All Trips</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {trips.map((trip, index) => {
                            const isViewable = canViewTrip(trip);
                            const isExpired = !isViewable;
                            
                            return (
                                <motion.div 
                                    key={trip.id}
                                    initial={{ opacity: 0, y: 50 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ duration: 0.5, delay: index * 0.1 }}
                                >
                                <Card className={`glass-effect flex flex-col justify-between h-full hover-lift ${isExpired ? 'opacity-60' : ''}`}>
                                    <div>
                                        <CardHeader>
                                            <div className="flex justify-between items-start">
                                                <CardTitle className="text-[#297479]">{trip.title || 'Untitled Trip'}</CardTitle>
                                                {isExpired && (
                                                    <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-full">Expired</span>
                                                )}
                                            </div>
                                            <CardDescription>
                                                {trip.request_description 
                                                    ? `${trip.request_description.substring(0, 100)}${trip.request_description.length > 100 ? '...' : ''}` 
                                                    : 'No description provided.'}
                                            </CardDescription>
                                        </CardHeader>
                                        <CardContent className="space-y-3 text-sm">
                                            <div className="flex items-center text-gray-700"><Calendar className="w-4 h-4 mr-2 text-orange-500" /> {trip.duration ? `${trip.duration} days` : 'N/A'}</div>
                                            <div className="flex items-center text-gray-700"><DollarSign className="w-4 h-4 mr-2 text-lime-500" /> {trip.budget || 'N/A'}</div>
                                            <div className="flex items-center text-gray-700"><MapPin className="w-4 h-4 mr-2 text-red-500" /> {trip.travel_style || 'N/A'}</div>
                                            <div className="text-xs text-gray-500">Created: {trip.created_date ? new Date(trip.created_date).toLocaleDateString() : 'N/A'}</div>
                                        </CardContent>
                                    </div>
                                    <CardFooter className="flex justify-between">
                                        <Button 
                                            variant="secondary" 
                                            size="sm" 
                                            onClick={() => handleViewTrip(trip)} 
                                            className="bg-[#297479] hover:bg-[#297479]/90 text-white"
                                            disabled={isExpired}
                                        >
                                            View Trip
                                        </Button>
                                        <AlertDialog>
                                          <AlertDialogTrigger asChild>
                                            <Button variant="destructive" size="icon" className="bg-red-500/80 hover:bg-red-500">
                                                <Trash2 className="w-4 h-4" />
                                            </Button>
                                          </AlertDialogTrigger>
                                          <AlertDialogContent>
                                            <AlertDialogHeader>
                                              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                              <AlertDialogDescription>
                                                This will permanently delete your saved itinerary for "{trip.title || 'this trip'}". This action cannot be undone.
                                              </AlertDialogDescription>
                                            </AlertDialogHeader>
                                            <AlertDialogFooter>
                                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                                              <AlertDialogAction onClick={() => handleDelete(trip.id)} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction>
                                            </AlertDialogFooter>
                                          </AlertDialogContent>
                                        </AlertDialog>
                                    </CardFooter>
                                </Card>
                                </motion.div>
                            )
                        })}
                    </div>
                </div>
            )}
        </div>

        {/* Trip Viewer Modal */}
        <AnimatePresence>
            {viewingTrip && (
                <TripViewer 
                    trip={viewingTrip}
                    onClose={() => setViewingTrip(null)}
                    onEmailTrip={handleEmailTrip}
                />
            )}
        </AnimatePresence>
        </>
    );
}
