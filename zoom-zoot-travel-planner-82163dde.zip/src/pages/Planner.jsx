
import React, { useState, useEffect } from 'react';
import PopularRequests from '../components/planner/PopularRequests';
import InfoPanel from '../components/planner/InfoPanel';
import ChatInterface from '../components/planner/ChatInterface';
import ResultsDisplay from '../components/planner/ResultsDisplay';
import { InvokeLLM } from '@/api/integrations';
import { processChat } from '@/api/functions';
import { getFlights } from '@/api/functions';
import { getHotels } from '@/api/functions';
import { getGooglePlaces } from '@/api/functions';
import { getDirections } from '@/api/functions';
import { User } from '@/api/entities';
import { useToast } from "@/components/ui/use-toast";
import { Toaster } from "@/components/ui/toaster";
import { AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { BookOpen, Map, Newspaper } from 'lucide-react';

const initialMessages = [
    { role: 'assistant', content: "Hi there! I'm ZoomZoot, your personal travel planner. What kind of Southeast Asia adventure can I help you dream up today?" }
];

// List of valid destinations to enforce the SEA-only constraint
const validSEADestinations = [
    'Bangkok', 'Thailand', 'Phuket', 'Chiang Mai', 'Pattaya',
    'Bali', 'Jakarta', 'Indonesia', 'Yogyakarta', 'Ubud',
    'Vietnam', 'Ho Chi Minh', 'Ho Chi Minh City', 'Saigon', 'Hanoi', 'Da Nang', 'Hoi An',
    'Singapore',
    'Kuala Lumpur', 'Malaysia', 'Penang',
    'Manila', 'Philippines', 'Cebu', 'Boracay', 'Palawan',
    'Phnom Penh', 'Cambodia', 'Siem Reap',
    'Vientiane', 'Laos', 'Luang Prabang',
    'Yangon', 'Myanmar', 'Mandalay'
].map(d => d.toLowerCase());

// Placeholder MascotIcon - if it's supposed to be an external component, it would be imported.
// For the sake of a self-contained, valid file, I will define a simple one here.
const MascotIcon = ({ width = 24, height = 24, className = '' }) => (
    <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className={className}
        width={width}
        height={height}
    >
        <circle cx="12" cy="12" r="10" />
        <path d="M8 14s1.5 2 4 2 4-2 4-2" />
        <line x1="9" y1="9" x2="9.01" y2="9" />
        <line x1="15" y1="9" x2="15.01" y2="9" />
    </svg>
);

export default function PlannerPage() {
    const [messages, setMessages] = useState(initialMessages);
    const [isProcessing, setIsProcessing] = useState(false);
    const [isGenerating, setIsGenerating] = useState(false);
    const [generatingProgress, setGeneratingProgress] = useState('');
    const [generatedPlan, setGeneratedPlan] = useState(null);
    const [userSubscription, setUserSubscription] = useState('free');
    const [userCurrency, setUserCurrency] = useState('USD');
    const [isAuthenticated, setIsAuthenticated] = useState(false); // New state to track auth
    const [showMobilePanel, setShowMobilePanel] = useState(null);
    const [isMobile, setIsMobile] = useState(false);
    const { toast } = useToast();

    useEffect(() => {
        loadUserData();
        
        // Safe mobile detection that handles cross-origin restrictions
        const checkIsMobile = () => {
            let screenWidth = window.innerWidth;
            
            // Try to access parent window width, but handle security errors gracefully
            try {
                // If running in an iframe and parent is accessible (same origin)
                if (window.top && window.top !== window) {
                    screenWidth = window.top.innerWidth;
                }
            } catch (e) {
                // Cross-origin access blocked, use current window width
                // This is expected if the app is embedded cross-origin
                console.warn("Could not access window.top.innerWidth due to cross-origin restrictions. Using current window's width.", e);
            }
            
            const isMobileSize = screenWidth < 1024;
            setIsMobile(isMobileSize);
        };
        
        checkIsMobile();
        
        // Add resize listener to current window (always safe)
        window.addEventListener('resize', checkIsMobile);
        
        return () => window.removeEventListener('resize', checkIsMobile);
    }, []);

    const loadUserData = async () => {
        try {
            const user = await User.me();
            setUserSubscription(user.subscription_type || 'free');
            setUserCurrency(user.preferred_currency || 'USD');
            setIsAuthenticated(true); // User is authenticated
        } catch (error) {
            console.log('[pages/Planner.js] Could not load user data, user is likely not logged in:', error);
            setIsAuthenticated(false); // User is not authenticated
        }
    };
    
    const handleSendMessage = async (userInput, isSystemMessage = false) => {
        // --- AUTHENTICATION CHECK ---
        if (!isAuthenticated) {
            toast({
                title: "Please Log In",
                description: "You need to be logged in to chat with the AI planner.",
                action: <Button onClick={() => User.login()}>Log In</Button>,
            });
            return; // Stop the function if not authenticated
        }
        
        const newUserMessage = { role: 'user', content: userInput };
        const currentMessages = isSystemMessage ? messages : [...messages, newUserMessage];
        
        if (!isSystemMessage) {
            setMessages(currentMessages);
        }
        
        setIsProcessing(true);

        try {
            const response = await processChat({
                messages: currentMessages,
                userSubscription,
                userCurrency,
            });

            console.log('ProcessChat response:', response); // Debug logging

            if (response.data?.reply) {
                if (response.data.reply.includes("PLAN_READY")) {
                    // AI is ready to generate the plan.
                    setMessages(prev => [...prev, { role: 'assistant', content: "Awesome! I have everything I need. Generating your personalized travel plan now. This might take a moment..." }]);
                    await generateFullPlan(currentMessages);
                } else {
                    setMessages(prev => [...prev, { role: 'assistant', content: response.data.reply }]);
                }
            } else {
                console.error('Empty or invalid response from processChat:', response);
                throw new Error(response.data?.error || "I received an empty response. Let's try that again.");
            }
        } catch (error) {
            console.error("[pages/Planner.js] Error processing chat:", error);
            const errorMessage = error.response?.data?.error || error.message || "I'm having a little trouble connecting. Please check your connection and try again.";
            setMessages(prev => [...prev, { role: 'assistant', content: errorMessage }]);
        } finally {
            setIsProcessing(false);
        }
    };

    const handleSelectRequest = (request) => {
        const message = `I'd like to plan a trip like the "${request.title}" popular request. It's a ${request.description}.`;
        handleSendMessage(message);
        setShowMobilePanel(null);
    };

    const handleSelectCountry = (country) => {
        const message = `I'm interested in planning a trip to ${country}.`;
        handleSendMessage(message);
        setShowMobilePanel(null);
    };

    const responseSchema = {
        type: "object",
        properties: {
            title: { type: "string" },
            summary: { type: "string" },
            daily_itinerary: {
                type: "array",
                items: {
                    type: "object",
                    properties: {
                        day: { type: "number" },
                        title: { type: "string" },
                        activities: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    time: { type: "string" },
                                    description: { type: "string" }
                                },
                                required: ["time", "description"]
                            }
                        }
                    },
                    required: ["day", "title", "activities"]
                }
            },
            flights: {
                type: "array",
                items: {
                    type: "object",
                    properties: {
                        airline: { type: "string" },
                        details: { type: "string" },
                        price: { type: "number" },
                        link: { type: "string" }
                    },
                    required: ["airline", "details", "price", "link"]
                }
            },
            accommodations: {
                type: "array",
                items: {
                    type: "object",
                    properties: {
                        name: { type: "string" },
                        details: { type: "string" },
                        price_per_night: { type: "number" },
                        link: { type: "string" }
                    },
                    required: ["name", "details", "price_per_night", "link"]
                }
            }
        },
        required: ["title", "summary", "daily_itinerary", "flights", "accommodations"]
    };

    const generateFullPlan = async (chatHistory) => {
        setIsGenerating(true);
        setGeneratedPlan(null);
        
        // Show progress updates
        setGeneratingProgress("Analyzing your conversation...");
        
        const planPrompt = `
Your task is to generate a complete and detailed travel plan based on the provided conversation.
Use your web search capabilities to find realistic flight options, hotel suggestions, and interesting activities.
Return ONLY a valid JSON object based on the schema.

**CRITICAL INSTRUCTIONS:**
- The final JSON object MUST be fully populated.
- Do NOT return empty arrays for "daily_itinerary", "flights", or "accommodations".
- The plan must be highly relevant to the user's request from the conversation.
- URL RULE: Never include URLs in the 'details' or 'description' fields. URLs must ONLY be placed in the dedicated 'link' field.

CONVERSATION:
${chatHistory.map(m => `${m.role}: ${m.content}`).join('\n')}

Based on this, create a complete and detailed travel plan.`;

        try {
            // Update progress with timeouts to reflect web search
            setTimeout(() => {
                if (isGenerating) setGeneratingProgress("Researching destinations & activities...");
            }, 2000);
            
            setTimeout(() => {
                if (isGenerating) setGeneratingProgress("Finding live flights & accommodations...");
            }, 6000);
            
            setTimeout(() => {
                if (isGenerating) setGeneratingProgress("Crafting your perfect itinerary...");
            }, 10000);

            const result = await Promise.race([
                InvokeLLM({
                    prompt: planPrompt,
                    response_json_schema: responseSchema,
                    add_context_from_internet: true 
                }),
                // 30 second timeout to allow for web searches
                new Promise((_, reject) => 
                    setTimeout(() => reject(new Error('Generation timeout')), 30000)
                )
            ]);

            setGeneratingProgress("Almost ready...");
            setGeneratedPlan(result);
            
            // Scroll to results after a brief delay
            setTimeout(() => {
                document.getElementById('results-container')?.scrollIntoView({ 
                    behavior: 'smooth', 
                    block: 'start' 
                });
            }, 500);

        } catch (error) {
            console.error("Error generating travel plan:", error);
            
            if (error.message === 'Generation timeout') {
                toast({
                    variant: "destructive",
                    title: "Generation Taking Too Long",
                    description: "The AI is working hard on your plan. Please try again.",
                });
            } else {
                toast({
                    variant: "destructive",
                    title: "Generation Failed",
                    description: "Could not generate the plan. Please try starting a new conversation.",
                });
            }
        } finally {
            setIsGenerating(false);
            setGeneratingProgress('');
        }
    };

    const handleFineTune = async (fineTunePrompt) => {
        // This will now be handled via the chat interface
        handleSendMessage(`Let's refine the plan. ${fineTunePrompt}`);
    };

    return (
        <>
            <Toaster />
            <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 min-h-screen pt-16 sm:pt-28">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
                    {/* Desktop-only side panel */}
                    <div className="hidden lg:block">
                        <PopularRequests onSelectRequest={handleSelectRequest} />
                    </div>

                    <div>
                        {/* Mobile-only navigation tabs - only show on mobile */}
                        {isMobile && (
                            <div className="grid grid-cols-3 gap-2 mb-4">
                                <Button
                                    variant={showMobilePanel === 'popular' ? 'default' : 'outline'}
                                    className={`flex-col h-auto py-2 transition-colors ${
                                        showMobilePanel === 'popular'
                                            ? 'bg-[#297479] hover:bg-[#297479]/90 text-white'
                                            : 'hover:bg-[#297479] hover:text-white border-gray-300'
                                    }`}
                                    onClick={() => setShowMobilePanel(showMobilePanel === 'popular' ? null : 'popular')}
                                >
                                    <BookOpen className="w-5 h-5 mb-1 text-orange-500"/>
                                    <span className="text-xs">Popular</span>
                                </Button>
                                <Button
                                    variant={showMobilePanel === 'explore' ? 'default' : 'outline'}
                                    className={`flex-col h-auto py-2 transition-colors ${
                                        showMobilePanel === 'explore'
                                            ? 'bg-[#297479] hover:bg-[#297479]/90 text-white'
                                            : 'hover:bg-[#297479] hover:text-white border-gray-300'
                                    }`}
                                    onClick={() => setShowMobilePanel(showMobilePanel === 'explore' ? null : 'explore')}
                                >
                                    <Map className="w-5 h-5 mb-1 text-lime-500"/>
                                    <span className="text-xs">SE Asia</span>
                                </Button>
                                <Button
                                    variant={showMobilePanel === 'visa' ? 'default' : 'outline'}
                                    className={`flex-col h-auto py-2 transition-colors ${
                                        showMobilePanel === 'visa'
                                            ? 'bg-[#297479] hover:bg-[#297479]/90 text-white'
                                            : 'hover:bg-[#297479] hover:text-white border-gray-300'
                                    }`}
                                    onClick={() => setShowMobilePanel(showMobilePanel === 'visa' ? null : 'visa')}
                                >
                                    <Newspaper className="w-5 h-5 mb-1 text-teal-500"/>
                                    <span className="text-xs">Visa News</span>
                                </Button>
                            </div>
                        )}

                        {/* Mobile content panels - only show on mobile when panel is selected */}
                        {isMobile && showMobilePanel === 'popular' && (
                            <div className="mb-4">
                                <PopularRequests onSelectRequest={handleSelectRequest} />
                            </div>
                        )}
                        {isMobile && showMobilePanel === 'explore' && (
                            <div className="mb-4">
                                <InfoPanel onSelectCountry={handleSelectCountry} mobileView="explore" />
                            </div>
                        )}
                        {isMobile && showMobilePanel === 'visa' && (
                            <div className="mb-4">
                                <InfoPanel onSelectCountry={() => {}} mobileView="visa" />
                            </div>
                        )}

                        {/* Show ChatInterface when no mobile panel is selected OR on desktop */}
                        {(!isMobile || !showMobilePanel) && (
                           <ChatInterface 
                                messages={messages}
                                onSendMessage={handleSendMessage}
                                isProcessing={isProcessing || isGenerating}
                           />
                        )}
                        
                        {/* Plan Generation Progress Indicator */}
                        {isGenerating && (
                            <div className="glass-effect rounded-3xl p-6 mt-4 text-center">
                                <div className="flex items-center justify-center mb-4">
                                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#297479] mr-3"></div>
                                    <MascotIcon width={32} height={32} className="animate-pulse" />
                                </div>
                                <h3 className="text-lg font-bold text-[#297479] mb-2">Creating Your Perfect Trip</h3>
                                <p className="text-sm text-gray-600 mb-4">{generatingProgress || "Working on your personalized plan..."}</p>
                                <div className="w-full bg-gray-200 rounded-full h-2">
                                    <div className="bg-gradient-to-r from-[#297479] to-[#f67a24] h-2 rounded-full animate-pulse w-3/4"></div>
                                </div>
                                <p className="text-xs text-gray-500 mt-2">This usually takes 10-20 seconds</p>
                            </div>
                        )}
                    </div>

                    {/* Desktop-only side panel */}
                    <div className="hidden lg:block">
                        <InfoPanel onSelectCountry={handleSelectCountry} />
                    </div>
                </div>

                <div id="results-container">
                    <AnimatePresence>
                      {generatedPlan && (
                        <ResultsDisplay
                            plan={generatedPlan}
                            requestData={{}} 
                            onFineTune={handleFineTune}
                            isGenerating={isGenerating}
                            userSubscription={userSubscription}
                            userCurrency={userCurrency}
                        />
                      )}
                    </AnimatePresence>
                </div>
            </div>
        </>
    );
}
