
import React, { useState, useEffect, useCallback } from 'react';
import { User } from '@/api/entities';
import { Itinerary } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { ArrowLeft, User as UserIcon, Bell, Shield, Trash2, Check, RefreshCw } from 'lucide-react';
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useToast } from "@/components/ui/use-toast";
import { Toaster } from "@/components/ui/toaster";
import { motion, AnimatePresence } from "framer-motion";

export default function SettingsPage() {
    const [user, setUser] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
    const [deleteConfirmText, setDeleteConfirmText] = useState('');
    const [isResetting, setIsResetting] = useState(false);
    const [settings, setSettings] = useState({
        emailNotifications: true,
        pushNotifications: false,
        travelReminders: true,
        marketingEmails: false
    });
    const { toast } = useToast();

    const loadUserData = useCallback(async () => {
        setIsLoading(true);
        try {
            const currentUser = await User.me();
            setUser(currentUser);
            setIsAuthenticated(true);
            
            // Load user settings if they exist
            if (currentUser.settings) {
                setSettings(prevSettings => ({ ...prevSettings, ...currentUser.settings }));
            }
        } catch (error) {
            console.log("User not authenticated:", error);
            setIsAuthenticated(false);
        }
        setIsLoading(false);
    }, []);

    useEffect(() => {
        loadUserData();
    }, [loadUserData]);

    const handleSettingChange = async (key, value) => {
        const newSettings = { ...settings, [key]: value };
        setSettings(newSettings);
        
        try {
            await User.updateMyUserData({ settings: newSettings });
            toast({
                title: "Settings Updated",
                description: "Your preferences have been saved.",
            });
        } catch (error) {
            console.error("Failed to update settings:", error);
            toast({
                variant: "destructive",
                title: "Error",
                description: "Failed to save settings. Please try again.",
            });
        }
    };

    const handleDeleteAccount = async () => {
        if (deleteConfirmText.toLowerCase() !== 'delete my account') {
            toast({
                variant: "destructive",
                title: "Incorrect Confirmation",
                description: "Please type 'delete my account' exactly as shown.",
            });
            return;
        }

        try {
            // Delete all user's itineraries first
            const userTrips = await Itinerary.filter({ created_by: user.email });
            for (const trip of userTrips) {
                await Itinerary.delete(trip.id);
            }

            // Logout user (account deletion would be handled server-side)
            await User.logout();
            
            toast({
                title: "Account Deleted",
                description: "Your account and all data have been deleted.",
            });
        } catch (error) {
            console.error("Failed to delete account:", error);
            toast({
                variant: "destructive",
                title: "Error",
                description: "Failed to delete account. Please try again.",
            });
        }
    };

    const handleResetSubscription = async () => {
        setIsResetting(true);
        try {
            await User.updateMyUserData({ subscription_type: 'free', premium_expiry_date: null });
            toast({
                title: "Subscription Reset",
                description: "Your account has been reset to the 'Free' plan.",
            });
            // Reload user data to reflect change
            await loadUserData();
        } catch (error) {
            console.error("Failed to reset subscription:", error);
            toast({
                variant: "destructive",
                title: "Error",
                description: "Could not reset subscription. Please try again.",
            });
        } finally {
            setIsResetting(false);
        }
    };

    if (isLoading) {
        return (
            <div className="max-w-md mx-auto p-6 space-y-4 pt-16 sm:pt-28">
                <div className="animate-pulse space-y-4">
                    <div className="h-4 bg-gray-300 rounded w-1/2"></div>
                    <div className="h-20 bg-gray-300 rounded"></div>
                    <div className="h-32 bg-gray-300 rounded"></div>
                </div>
            </div>
        );
    }

    // Show login prompt for unauthenticated users
    if (!isAuthenticated) {
        return (
            <div className="max-w-md mx-auto p-6 pt-16 sm:pt-28">
                <Toaster />
                <div className="text-center glass-effect rounded-2xl p-8">
                    <h1 className="text-2xl font-bold text-[#297479] mb-4">Settings</h1>
                    <p className="text-gray-600 mb-6">Please log in to access your account settings.</p>
                    <Button 
                        onClick={() => User.login()}
                        className="bg-[#297479] hover:bg-[#297479]/90 text-white"
                    >
                        Log In
                    </Button>
                </div>
            </div>
        );
    }

    if (showDeleteConfirm) {
        return (
            <div className="max-w-md mx-auto p-6 bg-white border border-gray-200 rounded-lg shadow-lg overflow-hidden pt-16 sm:pt-28" style={{ minHeight: "900px", width: "380px", margin: "20px auto" }}>
                <Toaster />
                <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center"
                >
                    <div className="text-6xl mb-6">⚠️</div>
                    <h2 className="text-2xl font-bold mb-4 text-red-600">Delete Account</h2>
                    <p className="text-gray-600 mb-6">
                        This action cannot be undone. All your saved trips and account data will be permanently deleted.
                    </p>
                    
                    <div className="mb-6">
                        <p className="text-sm font-semibold mb-2">Type "delete my account" to confirm:</p>
                        <Input
                            value={deleteConfirmText}
                            onChange={(e) => setDeleteConfirmText(e.target.value)}
                            placeholder="delete my account"
                            className="text-center"
                        />
                    </div>
                    
                    <div className="space-y-3">
                        <Button 
                            onClick={handleDeleteAccount}
                            className="w-full bg-red-600 hover:bg-red-700 text-white"
                            disabled={deleteConfirmText.toLowerCase() !== 'delete my account'}
                        >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete My Account
                        </Button>
                        
                        <Button 
                            onClick={() => {
                                setShowDeleteConfirm(false);
                                setDeleteConfirmText('');
                            }}
                            variant="outline"
                            className="w-full"
                        >
                            Cancel
                        </Button>
                    </div>
                </motion.div>
            </div>
        );
    }

    return (
        <div className="max-w-md mx-auto p-6 bg-white border border-gray-200 rounded-lg shadow-lg overflow-hidden pt-16 sm:pt-28" style={{ minHeight: "900px", width: "380px", margin: "20px auto" }}>
            <Toaster />
            
            {/* Header */}
            <motion.div 
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center mb-6"
            >
                <Button asChild variant="ghost" size="icon" className="mr-3">
                    <Link to={createPageUrl("Dashboard")}>
                        <ArrowLeft className="w-5 h-5" />
                    </Link>
                </Button>
                <h1 className="text-2xl font-bold" style={{ color: '#297479' }}>Settings</h1>
            </motion.div>

            <div className="space-y-6">
                {/* Account Information */}
                <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 }}
                >
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center text-lg">
                                <UserIcon className="w-5 h-5 mr-2" style={{ color: '#297479' }} />
                                Account Information
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div>
                                <label className="text-sm font-semibold text-gray-600">Full Name</label>
                                <p className="text-lg">{user?.full_name || 'Not provided'}</p>
                            </div>
                            <div>
                                <label className="text-sm font-semibold text-gray-600">Email</label>
                                <p className="text-lg">{user?.email}</p>
                            </div>
                            <div>
                                <label className="text-sm font-semibold text-gray-600">Account Type</label>
                                <p className="text-lg capitalize">
                                    {user?.subscription_type === 'premium' && 'Premium User'}
                                    {user?.subscription_type === 'standard' && 'Standard User'}
                                    {(!user?.subscription_type || user?.subscription_type === 'free') && 'Free User'}
                                </p>
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>

                {/* Notification Settings */}
                <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                >
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center text-lg">
                                <Bell className="w-5 h-5 mr-2" style={{ color: '#f67a24' }} />
                                Notifications
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="font-semibold">Email Notifications</p>
                                    <p className="text-sm text-gray-600">Get notified about your trips via email</p>
                                </div>
                                <Switch
                                    checked={settings.emailNotifications}
                                    onCheckedChange={(checked) => handleSettingChange('emailNotifications', checked)}
                                />
                            </div>
                            
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="font-semibold">Travel Reminders</p>
                                    <p className="text-sm text-gray-600">Reminders about upcoming trips</p>
                                </div>
                                <Switch
                                    checked={settings.travelReminders}
                                    onCheckedChange={(checked) => handleSettingChange('travelReminders', checked)}
                                />
                            </div>
                            
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="font-semibold">Marketing Emails</p>
                                    <p className="text-sm text-gray-600">Receive travel deals and updates</p>
                                </div>
                                <Switch
                                    checked={settings.marketingEmails}
                                    onCheckedChange={(checked) => handleSettingChange('marketingEmails', checked)}
                                />
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>

                {/* Privacy & Data */}
                <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                >
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center text-lg">
                                <Shield className="w-5 h-5 mr-2" style={{ color: '#aab624' }} />
                                Privacy & Data
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <Button 
                                asChild
                                variant="outline" 
                                className="w-full justify-start"
                            >
                                <Link to={createPageUrl("PrivacyPolicy")}>
                                    View Privacy Policy
                                </Link>
                            </Button>
                            
                            <Button 
                                variant="outline" 
                                className="w-full justify-start"
                                onClick={() => toast({ title: "Data Export", description: "Data export would start here." })}
                            >
                                Export My Data
                            </Button>
                             {/* Subscription Reset Button */}
                            <Button 
                                variant="outline" 
                                className="w-full justify-start border-blue-500 text-blue-600 hover:bg-blue-50 hover:text-blue-700"
                                onClick={handleResetSubscription}
                                disabled={isResetting}
                            >
                                <RefreshCw className={`w-4 h-4 mr-2 ${isResetting ? 'animate-spin' : ''}`} />
                                {isResetting ? 'Resetting...' : 'Reset to Free Plan (Testing)'}
                            </Button>
                            
                            <Button 
                                variant="destructive" 
                                className="w-full justify-start bg-red-50 text-red-600 border-red-200 hover:bg-red-100"
                                onClick={() => setShowDeleteConfirm(true)}
                            >
                                <Trash2 className="w-4 h-4 mr-2" />
                                Delete Account
                            </Button>
                        </CardContent>
                    </Card>
                </motion.div>

                {/* Logout */}
                <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                    className="pb-6"
                >
                    <Button 
                        onClick={() => User.logout()}
                        variant="outline" 
                        className="w-full"
                        style={{ borderColor: '#297479', color: '#297479' }}
                    >
                        Logout
                    </Button>
                </motion.div>
            </div>
        </div>
    );
}
