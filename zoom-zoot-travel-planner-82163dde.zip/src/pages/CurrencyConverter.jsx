
import React, { useState, useEffect, useCallback } from 'react';
import { User } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowUpDown, Crown, Star, Clock, Wifi, WifiOff, RefreshCw, Sparkles, Bot } from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";
import { Toaster } from "@/components/ui/toaster";
import { motion, AnimatePresence } from "framer-motion";
import { fetchExchangeRates } from '@/api/functions';

const currencies = [
    { code: 'USD', name: 'US Dollar', symbol: '$', flag: '🇺🇸' },
    { code: 'EUR', name: 'Euro', symbol: '€', flag: '🇪🇺' },
    { code: 'GBP', name: 'British Pound', symbol: '£', flag: '🇬🇧' },
    { code: 'CAD', name: 'Canadian Dollar', symbol: 'C$', flag: '🇨🇦' },
    { code: 'AUD', name: 'Australian Dollar', symbol: 'A$', flag: '🇦🇺' },
    { code: 'JPY', name: 'Japanese Yen', symbol: '¥', flag: '🇯🇵' },
    { code: 'CNY', name: 'Chinese Yuan', symbol: '¥', flag: '🇨🇳' },
    { code: 'THB', name: 'Thai Baht', symbol: '฿', flag: '🇹🇭' },
    { code: 'VND', name: 'Vietnamese Dong', symbol: '₫', flag: '🇻🇳' },
    { code: 'IDR', name: 'Indonesian Rupiah', symbol: 'Rp', flag: '🇮🇩' },
    { code: 'MYR', name: 'Malaysian Ringgit', symbol: 'RM', flag: '🇲🇾' },
    { code: 'SGD', name: 'Singapore Dollar', symbol: 'S$', flag: '🇸🇬' },
    { code: 'PHP', name: 'Philippine Peso', symbol: '₱', flag: '🇵🇭' },
    { code: 'KHR', name: 'Cambodian Riel', symbol: '៛', flag: '🇰🇭' },
    { code: 'LAK', name: 'Lao Kip', symbol: '₭', flag: '🇱🇦' },
    { code: 'MMK', name: 'Myanmar Kyat', symbol: 'K', flag: '🇲🇲' }
];

export default function CurrencyConverterPage() {
    const [user, setUser] = useState(null);
    const [isLoading, setIsLoading] = useState(true); // This isLoading is for initial page load
    const [isConverting, setIsConverting] = useState(false); // New state for individual conversion loading
    const [rates, setRates] = useState(null);
    const [lastUpdated, setLastUpdated] = useState(null);
    const [isOffline, setIsOffline] = useState(false);
    
    const [amount, setAmount] = useState('100');
    const [fromCurrency, setFromCurrency] = useState('USD');
    const [toCurrency, setToCurrency] = useState('THB');
    const [convertedAmount, setConvertedAmount] = useState(null);
    const [exchangeRate, setExchangeRate] = useState(null); // New state for storing the rate
    const [favorites, setFavorites] = useState([]);
    const [recentConversions, setRecentConversions] = useState([]);
    const [userSubscription, setUserSubscription] = useState(null); // New state for subscription type
    
    const { toast } = useToast();

    const checkOnlineStatus = useCallback(() => {
        setIsOffline(!navigator.onLine);
    }, []);

    const loadExchangeRates = useCallback(async (isProUser) => {
        try {
            // Try to get cached rates first (for offline support)
            const cachedRates = localStorage.getItem('zoomzoot_exchange_rates');
            const cachedTimestamp = localStorage.getItem('zoomzoot_rates_timestamp');
            
            if (cachedRates && cachedTimestamp && isProUser) {
                const parsedRates = JSON.parse(cachedRates);
                setRates(parsedRates);
                setLastUpdated(new Date(cachedTimestamp));
            }
            
            // Fetch fresh rates if online
            if (!isOffline) {
                // FIX: Provide the 'target_currencies' array as required by the backend function.
                const allCurrencyCodes = currencies.map(c => c.code);
                const response = await fetchExchangeRates({ 
                    base_currency: 'USD',
                    target_currencies: allCurrencyCodes 
                });

                if (response.data && response.data.success) {
                    const freshRates = response.data.rates;
                    setRates(freshRates); 
                    setLastUpdated(new Date(response.data.last_updated));
                    
                    // Cache for Pro users only
                    if (isProUser) {
                        localStorage.setItem('zoomzoot_exchange_rates', JSON.stringify(freshRates));
                        localStorage.setItem('zoomzoot_rates_timestamp', response.data.last_updated);
                    }
                }
            }
        } catch (error) {
            console.error('Failed to load exchange rates:', error);
            toast({
                variant: "destructive",
                title: "Rate Loading Failed",
                description: "Could not load current exchange rates. Please try again.",
            });
        }
    }, [isOffline, toast]);

    const loadUserAndRates = useCallback(async () => {
        setIsLoading(true);
        try {
            const currentUser = await User.me();
            setUser(currentUser);
            setUserSubscription(currentUser.subscription_type); // Set the new subscription state
            setFavorites(currentUser.currency_favorites || []);
            setRecentConversions(currentUser.last_conversions || []);
            
            // Pass the correct subscription type for rate loading
            await loadExchangeRates(currentUser.subscription_type === 'pro' || currentUser.subscription_type === 'premium');
        } catch (error) {
            console.error("Failed to load user data:", error);
        }
        setIsLoading(false);
    }, [loadExchangeRates]);

    // Modified saveToRecentConversions based on the outline
    // This function is now responsible for updating both local state and the backend
    const saveToRecentConversions = useCallback(async (conversion) => {
        try {
            let conversionsForBackend = [];
            // Update local state using functional update to ensure we have the latest `prevConversions`
            setRecentConversions(prevConversions => {
                const updated = [conversion, ...prevConversions.slice(0, 4)];
                conversionsForBackend = updated; // Capture the updated list for the backend call
                return updated;
            });
            
            // Update backend with the latest state
            await User.updateMyUserData({ 
                last_conversions: conversionsForBackend 
            });
        } catch (error) {
            console.log('Could not save conversion:', error); // Changed to console.log as per outline
            toast({
                variant: "destructive",
                title: "Failed to Save Conversion",
                description: "Your recent conversion could not be saved to your profile.",
            });
        }
    }, [toast]); // Now, it only depends on toast, making it more stable


    // New handleConversion function, replacing the old convertCurrency logic
    const handleConversion = useCallback(async () => {
        if (!amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
            toast({
                variant: "destructive",
                title: "Invalid Amount",
                description: "Please enter a valid amount to convert."
            });
            setConvertedAmount(null); // Clear previous result
            setExchangeRate(null); // Clear previous rate
            return;
        }

        const numericAmount = parseFloat(amount);

        if (fromCurrency === toCurrency) {
            setConvertedAmount(numericAmount);
            setExchangeRate(1); // Rate is 1 when currencies are the same
            return;
        }

        setIsConverting(true); // Start conversion loading
        try {
            // The fetchExchangeRates function now accepts base_currency and target_currencies
            const response = await fetchExchangeRates({
                base_currency: fromCurrency,
                target_currencies: [toCurrency]
            });

            if (response.data && response.data.success && response.data.rates && response.data.rates[toCurrency]) {
                const rate = response.data.rates[toCurrency];
                const result = (numericAmount * rate);
                setConvertedAmount(result);
                setExchangeRate(rate);

                // Save to recent conversions for Pro/Premium users
                if (userSubscription === 'pro' || userSubscription === 'premium') {
                    const conversion = {
                        from_currency: fromCurrency,
                        to_currency: toCurrency,
                        amount: numericAmount,
                        result: result,
                        timestamp: new Date().toISOString()
                    };
                    await saveToRecentConversions(conversion);
                    // The setRecentConversions call is now handled inside saveToRecentConversions
                }

                toast({
                    title: "Conversion Successful",
                    description: `${numericAmount} ${fromCurrency} = ${result.toFixed(2)} ${toCurrency}`,
                    duration: 3000 // Fixed: 3 second duration instead of default
                });
            } else {
                throw new Error('Rate not available or API error');
            }
        } catch (error) {
            console.error('Conversion failed:', error);
            toast({
                variant: "destructive",
                title: "Conversion Failed",
                description: "Could not fetch exchange rate. Please try again. Ensure you are online if not a Pro/Premium user."
            });
            setConvertedAmount(null); // Clear result on error
            setExchangeRate(null); // Clear rate on error
        } finally {
            setIsConverting(false); // End conversion loading
        }
    }, [amount, fromCurrency, toCurrency, userSubscription, saveToRecentConversions, toast]);


    useEffect(() => {
        loadUserAndRates();
        checkOnlineStatus();
        
        // Set up online/offline listeners
        const handleOnline = () => {
            setIsOffline(false);
            // Optionally, refresh rates when coming online
            const currentSubscription = user?.subscription_type;
            if (currentSubscription === 'pro' || currentSubscription === 'premium') {
                loadExchangeRates(true);
            }
        };
        const handleOffline = () => setIsOffline(true);
        
        window.addEventListener('online', handleOnline);
        window.addEventListener('offline', handleOffline);
        
        return () => {
            window.removeEventListener('online', handleOnline);
            window.removeEventListener('offline', handleOffline);
        };
    }, [loadUserAndRates, checkOnlineStatus, user?.subscription_type, loadExchangeRates]);

    const swapCurrencies = () => {
        setFromCurrency(toCurrency);
        setToCurrency(fromCurrency);
    };

    const toggleFavorite = async (fromCode, toCode) => {
        // Use the new userSubscription state for checks
        if (userSubscription !== 'pro' && userSubscription !== 'premium') {
            toast({
                title: "Pro Feature",
                description: "Upgrade to Pro/Premium to save favorite currency pairs.",
            });
            return;
        }

        try {
            const pairString = `${fromCode}-${toCode}`;
            let updatedFavorites;
            
            if (favorites.includes(pairString)) {
                updatedFavorites = favorites.filter(fav => fav !== pairString);
            } else {
                updatedFavorites = [...favorites, pairString];
            }
            
            setFavorites(updatedFavorites);
            
            await User.updateMyUserData({
                currency_favorites: updatedFavorites
            });
            
            toast({
                title: favorites.includes(pairString) ? "Removed from Favorites" : "Added to Favorites",
                description: `${fromCode} → ${toCode}`,
            });
        } catch (error) {
            console.error('Failed to toggle favorite:', error);
        }
    };

    const loadFavoritePair = (pairString) => {
        const [from, to] = pairString.split('-');
        setFromCurrency(from);
        setToCurrency(to);
    };

    useEffect(() => {
        // This effect is designed to run the conversion whenever the user
        // changes the 'from' or 'to' currency selections.
        // It now correctly includes all its dependencies.
        if (fromCurrency && toCurrency) {
            handleConversion();
        }
    }, [fromCurrency, toCurrency, handleConversion]);

    // Derived state for convenience
    const isProUser = userSubscription === 'pro' || userSubscription === 'premium';

    if (isLoading) {
        return (
            <div className="flex justify-center items-center min-h-screen px-4 py-8">
                <div className="max-w-md w-full p-6 bg-white border border-gray-200 rounded-lg shadow-lg" style={{ width: "380px" }}>
                    <div className="animate-pulse space-y-4">
                        <div className="h-4 bg-gray-300 rounded w-3/4"></div>
                        <div className="h-20 bg-gray-300 rounded"></div>
                        <div className="h-32 bg-gray-300 rounded"></div>
                    </div>
                </div>
            </div>
        );
    }

    // Show upgrade prompt for free/standard users
    if (!isProUser) {
        return (
            <div className="flex justify-center items-center min-h-screen px-4 py-8">
                <div className="max-w-md w-full p-6 bg-white border border-gray-200 rounded-lg shadow-lg pt-16 sm:pt-28" style={{ width: "380px" }}>
                    <Toaster />
                    <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="text-center"
                    >
                        {/* Updated to focus on yearly upgrade */}
                        <div className="bg-gradient-to-br from-indigo-50 to-purple-50 border-2 border-indigo-200 rounded-2xl p-6 mb-6">
                            {/* Yearly Premium Plan header/pricing */}
                            <div className="bg-gradient-to-br from-indigo-100 to-purple-100 rounded-xl p-4 border border-indigo-300 mb-4">
                                <div className="flex items-center justify-center mb-2">
                                    <Crown className="w-6 h-6 text-indigo-600 mr-2" />
                                    <h4 className="text-xl font-bold text-indigo-800">Premium Yearly Plan</h4>
                                </div>
                                <div className="text-center mb-2">
                                    <p className="text-2xl font-bold text-indigo-700">$129.99/year</p>
                                    <p className="text-sm text-green-600 font-semibold">Save 28% vs Monthly!</p>
                                </div>
                            </div>
                            
                            <p className="text-indigo-700 mb-4 font-medium">
                                Upgrade to yearly Premium and get full access to the currency converter plus all premium travel features!
                            </p>
                            
                            <ul className="text-sm text-indigo-700 space-y-2 mb-6 text-left">
                                <li className="flex items-center">
                                    <WifiOff className="w-4 h-4 mr-2 text-green-600" />
                                    Offline currency conversion
                                </li>
                                <li className="flex items-center">
                                    <Star className="w-4 h-4 mr-2 text-green-600" />
                                    Save favorite currency pairs
                                </li>
                                <li className="flex items-center">
                                    <Clock className="w-4 h-4 mr-2 text-green-600" />
                                    Conversion history tracking
                                </li>
                                <li className="flex items-center">
                                    <RefreshCw className="w-4 h-4 mr-2 text-green-600" />
                                    Live exchange rates
                                </li>
                                <li className="flex items-center font-semibold">
                                    <Sparkles className="w-4 h-4 mr-2 text-purple-600" />
                                    Unlimited premium trip planning
                                </li>
                                <li className="flex items-center font-semibold">
                                    <Bot className="w-4 h-4 mr-2 text-purple-600" />
                                    Enhanced AI travel features
                                </li>
                            </ul>
                            
                            <div className="text-center">
                                <Button 
                                    className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-semibold py-3 rounded-xl shadow-lg hover:shadow-xl transform hover:scale-105"
                                    onClick={() => {
                                        // Create checkout for yearly premium plan
                                        import('@/api/functions').then(({ createStripeCheckout }) => {
                                            createStripeCheckout({ planType: 'premium_yearly' })
                                                .then(response => {
                                                    let sessionUrl = null;
                                                    if (response?.data?.sessionUrl) {
                                                        sessionUrl = response.data.sessionUrl;
                                                    } else if (response?.sessionUrl) {
                                                        sessionUrl = response.sessionUrl;
                                                    }
                                                    
                                                    if (sessionUrl) {
                                                        window.top.location.href = sessionUrl;
                                                    } else {
                                                        toast({
                                                            variant: "destructive",
                                                            title: "Checkout Failed",
                                                            description: "Could not create checkout session. Please try again.",
                                                        });
                                                    }
                                                })
                                                .catch(error => {
                                                    console.error('Checkout error:', error);
                                                    toast({
                                                        variant: "destructive",
                                                        title: "Checkout Failed",
                                                        description: "Could not initiate checkout. Please try again.",
                                                    });
                                                });
                                        });
                                    }}
                                >
                                    <Crown className="w-5 h-5 mr-2" />
                                    Upgrade to Premium Yearly
                                </Button>
                                <p className="text-xs text-gray-500 mt-2">Best value for frequent travelers!</p>
                            </div>
                        </div>
                        
                        {/* Basic converter for demonstration */}
                        <div className="bg-gray-50 border border-gray-200 rounded-xl p-4">
                            <p className="text-sm text-gray-600 mb-3">Preview (Upgrade Required)</p>
                            <div className="space-y-3">
                                <Input
                                    placeholder="Amount"
                                    value="100"
                                    disabled
                                    className="text-center"
                                />
                                <div className="flex items-center space-x-2">
                                    <Select value="USD" disabled>
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                    </Select>
                                    <ArrowUpDown className="w-5 h-5 text-gray-400" />
                                    <Select value="THB" disabled>
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                    </Select>
                                </div>
                                <div className="text-center p-4 bg-white border border-gray-200 rounded-lg">
                                    <div className="text-2xl font-bold text-gray-400">≈ ฿3,400</div>
                                    <div className="text-xs text-gray-500 mt-1">Upgrade for live rates</div>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                </div>
            </div>
        );
    }

    // Main converter interface for Pro/Premium users
    return (
        <div className="flex justify-center items-center min-h-screen px-4 py-8">
            <div className="max-w-md w-full p-6 bg-white border border-gray-200 rounded-lg shadow-lg pt-16 sm:pt-28" style={{ width: "380px" }}>
                <Toaster />
                
                <motion.div 
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center mb-6"
                >
                    <div className="text-4xl mb-3">💱</div>
                    <h1 className="text-2xl font-bold" style={{ color: '#297479' }}>Currency Converter</h1>
                    <div className="flex items-center justify-center mt-2 space-x-2">
                        <Crown className="w-4 h-4 text-purple-600" />
                        <span className="text-sm text-purple-600 font-medium">Pro Feature</span>
                    </div>
                </motion.div>

                {/* Status Bar */}
                <div className="flex items-center justify-between mb-6 p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-2">
                        {isOffline ? <WifiOff className="w-4 h-4 text-red-500" /> : <Wifi className="w-4 h-4 text-green-500" />}
                        <span className="text-sm">{isOffline ? 'Offline' : 'Online'}</span>
                    </div>
                    {lastUpdated && (
                        <span className="text-xs text-gray-500">
                            Updated: {lastUpdated.toLocaleDateString()} {lastUpdated.toLocaleTimeString()}
                        </span>
                    )}
                </div>

                {/* Converter */}
                <Card>
                    <CardContent className="p-6 space-y-4">
                        <div>
                            <label className="block text-sm font-semibold mb-2">Amount</label>
                            <Input
                                type="number"
                                value={amount}
                                onChange={(e) => setAmount(e.target.value)}
                                placeholder="Enter amount"
                                className="text-center text-lg"
                                disabled={isConverting} // Disable input during conversion
                            />
                        </div>
                        
                        <div className="flex items-center space-x-2">
                            <div className="flex-1">
                                <label className="block text-sm font-semibold mb-2">From</label>
                                <Select value={fromCurrency} onValueChange={setFromCurrency} disabled={isConverting}>
                                    <SelectTrigger>
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {currencies.map(currency => (
                                            <SelectItem key={currency.code} value={currency.code}>
                                                <span className="flex items-center space-x-2">
                                                    <span>{currency.flag}</span>
                                                    <span>{currency.code}</span>
                                                    <span className="text-gray-500">({currency.symbol})</span>
                                                </span>
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            
                            <Button
                                variant="outline"
                                size="icon"
                                onClick={swapCurrencies}
                                className="mt-6"
                                disabled={isConverting} // Disable button during conversion
                            >
                                <ArrowUpDown className="w-4 h-4" />
                            </Button>
                            
                            <div className="flex-1">
                                <label className="block text-sm font-semibold mb-2">To</label>
                                <Select value={toCurrency} onValueChange={setToCurrency} disabled={isConverting}>
                                    <SelectTrigger>
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {currencies.map(currency => (
                                            <SelectItem key={currency.code} value={currency.code}>
                                                <span className="flex items-center space-x-2">
                                                    <span>{currency.flag}</span>
                                                    <span>{currency.code}</span>
                                                    <span className="text-gray-500">({currency.symbol})</span>
                                                </span>
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>

                        {/* Result */}
                        <div className="text-center p-4 bg-gradient-to-br from-teal-50 to-lime-50 border border-teal-200 rounded-lg">
                            {isConverting ? ( // Show loading spinner during conversion
                                <div className="flex justify-center items-center h-16">
                                    <RefreshCw className="w-6 h-6 animate-spin text-teal-600" />
                                </div>
                            ) : convertedAmount !== null ? (
                                <div>
                                    <div className="text-2xl font-bold text-teal-700">
                                        {currencies.find(c => c.code === toCurrency)?.symbol}
                                        {convertedAmount.toLocaleString(undefined, { 
                                            minimumFractionDigits: 2, 
                                            maximumFractionDigits: 2 
                                        })}
                                    </div>
                                    {exchangeRate && ( // Display exchange rate if available
                                        <p className="text-xs text-gray-500 mt-1">
                                            1 {fromCurrency} = {exchangeRate.toFixed(4)} {toCurrency}
                                        </p>
                                    )}
                                    <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => toggleFavorite(fromCurrency, toCurrency)}
                                        className="mt-2"
                                    >
                                        <Star className={`w-4 h-4 mr-1 ${favorites.includes(`${fromCurrency}-${toCurrency}`) ? 'text-yellow-500' : 'text-gray-400'}`} />
                                        {favorites.includes(`${fromCurrency}-${toCurrency}`) ? 'Favorited' : 'Add to Favorites'}
                                    </Button>
                                </div>
                            ) : (
                                <div className="text-gray-500">Enter amount to convert</div>
                            )}
                        </div>
                    </CardContent>
                </Card>

                {/* Favorites */}
                {favorites.length > 0 && (
                    <Card className="mt-4">
                        <CardHeader>
                            <CardTitle className="text-lg flex items-center">
                                <Star className="w-5 h-5 mr-2 text-yellow-500" />
                                Favorites
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-2">
                            {favorites.map((pairString) => {
                                const [from, to] = pairString.split('-');
                                return (
                                    <Button
                                        key={pairString}
                                        variant="outline"
                                        onClick={() => loadFavoritePair(pairString)}
                                        className="w-full justify-start text-sm"
                                    >
                                        {from} → {to}
                                    </Button>
                                );
                            })}
                        </CardContent>
                    </Card>
                )}

                {/* Recent Conversions */}
                {recentConversions.length > 0 && (
                    <Card className="mt-4">
                        <CardHeader>
                            <CardTitle className="text-lg flex items-center">
                                <Clock className="w-5 h-5 mr-2 text-blue-500" />
                                Recent
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-2">
                            {recentConversions.slice(0, 5).map((conversion, index) => (
                                <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded text-sm">
                                    <span>{conversion.amount} {conversion.from_currency} → {conversion.to_currency}</span>
                                    <span className="font-semibold">
                                        {currencies.find(c => c.code === conversion.to_currency)?.symbol}
                                        {conversion.result.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                                    </span>
                                </div>
                            ))}
                        </CardContent>
                    </Card>
                )}
            </div>
        </div>
    );
}
