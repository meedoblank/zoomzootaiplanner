
import React, { useEffect, useState } from 'react';
import { useLocation, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { CheckCircle, Sparkles, Plane, Calculator } from "lucide-react";
import { User } from '@/api/entities';
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import { MascotIcon } from "@/components/MascotIcon";

const planDetailsMap = {
  premium_monthly: { name: 'Premium Monthly', price: '$14.99/month' },
  premium_yearly: { name: 'Premium Yearly', price: '$129.99/year' },
};

export default function SubscriptionSuccessPage() {
    const [planDetails, setPlanDetails] = useState({ name: 'Premium Plan', price: '' });
    const location = useLocation();

    useEffect(() => {
        const params = new URLSearchParams(location.search);
        const planType = params.get('plan');
        const details = planDetailsMap[planType] || planDetailsMap.premium_monthly;
        setPlanDetails(details);

        // Immediately update user's subscription status on the frontend
        // This ensures instant access to premium features without waiting for the webhook
        const updateUserSubscription = async () => {
            try {
                // We just mark them as premium. The webhook handles the expiry date details.
                await User.updateMyUserData({ subscription_type: 'premium' });
            } catch (error) {
                console.error("Failed to optimistically update user subscription:", error);
            }
        };

        if (planType?.startsWith('premium')) {
            updateUserSubscription();
        }

    }, [location]);

    return (
        <div className="max-w-md mx-auto p-6 text-center space-y-6 pt-16">
            <motion.div
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, type: 'spring' }}
            >
                <MascotIcon width={80} height={80} className="mx-auto mascot-pulse" />
            </motion.div>

            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
            >
                <CheckCircle className="w-16 h-16 text-green-400 mx-auto" />
                <h1 className="text-3xl font-bold mt-4 text-white">Welcome to Premium!</h1>
                <p className="text-white/90 mt-2">
                    Your <span className="font-semibold text-white">{planDetails.name}</span> plan is now active.
                </p>
                <div className="bg-green-500/20 border border-green-400/50 rounded-lg p-3 mt-4">
                    <p className="text-green-100">Successfully charged: {planDetails.price}</p>
                </div>
            </motion.div>

            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="space-y-4 pt-4 border-t border-white/20"
            >
                <h2 className="text-xl font-semibold text-white">What's Next?</h2>
                <p className="text-white/90">
                    You've unlocked all premium features. Start exploring now!
                </p>
                <Button asChild className="w-full h-14 text-lg" style={{ background: 'linear-gradient(135deg, #297479 0%, #aab624 100%)', color: 'white' }}>
                    <Link to={createPageUrl("Planner")}>
                        <Sparkles className="w-5 h-5 mr-3" />
                        Create a Premium Trip
                    </Link>
                </Button>
                <Button asChild variant="outline" className="w-full h-12 border-2 border-white/50 text-green-500 hover:bg-white/10 hover:text-green-400">
                    <Link to={createPageUrl("CurrencyConverter")}>
                        <Calculator className="w-4 h-4 mr-2" />
                        Try the Pro Converter
                    </Link>
                </Button>
            </motion.div>
        </div>
    );
}
