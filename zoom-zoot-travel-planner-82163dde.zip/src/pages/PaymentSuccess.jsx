import React, { useEffect, useState } from 'react';
import { useLocation, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { CheckCircle, Sparkles, Plane, Calculator, Mail } from "lucide-react";
import { User } from '@/api/entities';
import { Itinerary } from '@/api/entities';
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import { MascotIcon } from "@/components/MascotIcon";
import { useToast } from "@/components/ui/use-toast";
import { Toaster } from "@/components/ui/toaster";
import { SendEmail } from '@/api/integrations';

const planDetailsMap = {
  standard: { name: 'Standard Plan', price: '$9.99', description: 'Perfect for individual trips!' }
};

export default function PaymentSuccessPage() {
    const [planDetails, setPlanDetails] = useState({ name: 'Standard Plan', price: '$9.99', description: 'Perfect for individual trips!' });
    const [trip, setTrip] = useState(null);
    const [isEmailSending, setIsEmailSending] = useState(false);
    const { toast } = useToast();
    const location = useLocation();

    useEffect(() => {
        const params = new URLSearchParams(location.search);
        const planType = params.get('plan');
        const itineraryId = params.get('itineraryId');
        
        if (planType) {
            const details = planDetailsMap[planType] || planDetailsMap.standard;
            setPlanDetails(details);
        }

        // Update user subscription status and load trip if available
        const updateUserAndLoadTrip = async () => {
            try {
                // Update user's subscription to standard
                await User.updateMyUserData({ subscription_type: 'standard' });
                
                // If there's an itineraryId, load the trip details
                if (itineraryId) {
                    try {
                        const tripData = await Itinerary.get(itineraryId);
                        setTrip(tripData);
                    } catch (error) {
                        console.error("Could not load trip details:", error);
                    }
                }
            } catch (error) {
                console.error("Failed to update user subscription:", error);
            }
        };

        updateUserAndLoadTrip();
    }, [location]);

    const handleSendEmail = async () => {
        if (!trip) return;
        
        setIsEmailSending(true);
        try {
            const user = await User.me();
            const plan = trip.generated_plan;
            
            if (!plan) {
                throw new Error("Generated plan not available for this trip.");
            }

            const dailyItineraryHtml = plan.daily_itinerary && plan.daily_itinerary.length > 0
                ? plan.daily_itinerary.map(day => `
                    <div style="margin-bottom: 15px;">
                        <h3 style="color: #297479;">Day ${day.day || 'N/A'}: ${day.title || 'N/A'}</h3>
                        ${(day.activities && Array.isArray(day.activities))
                            ? day.activities.map(activity => `
                                <div style="padding-left: 15px; border-left: 2px solid #eee; margin-bottom: 8px;">
                                    <p style="margin: 0;"><strong>${activity.time || ''}:</strong> ${activity.description || ''}</p>
                                    ${activity.transport_to_next ? `<p style="margin: 2px 0 0 0; color: #f67a24; font-size: 0.9em; font-style: italic;">&rarr; ${activity.transport_to_next}</p>` : ''}
                                </div>
                            `).join('')
                            : '<p>No activities listed for this day.</p>'
                        }
                    </div>
                `).join('')
                : '<p>No daily itinerary available for this plan.</p>';
            
            const flightsHtml = plan.flights && plan.flights.length > 0
                ? plan.flights.map(f => `<div style="margin-bottom: 10px;"><strong>${f.airline || 'N/A'}</strong>: ${f.details || 'N/A'} - $${f.price || 'N/A'} <a href="${f.link || '#'}" target="_blank">Book Here</a></div>`).join('')
                : '<p>No specific flights in this plan.</p>';

            const accommodationsHtml = plan.accommodations && plan.accommodations.length > 0
                ? plan.accommodations.map(a => `<div style="margin-bottom: 10px;"><strong>${a.name || 'N/A'}</strong>: ${a.details || 'N/A'} - $${a.price_per_night || 'N/A'}/night USD <a href="${a.link || '#'}" target="_blank">Book Here</a></div>`).join('')
                : '<p>No specific accommodations in this plan.</p>';

            const emailBody = `
                <div style="font-family: sans-serif; line-height: 1.6;">
                    <h1>Your ZoomZoot Travel Plan: ${trip.title || 'N/A'}</h1>
                    <p>Thank you for purchasing the Standard Plan! Here's your complete itinerary.</p>
                    <p>Based on your request: "<em>${trip.request_description || 'N/A'}</em>"</p>
                    <hr>
                    <h2>Summary</h2>
                    <p>${plan.summary || 'N/A'}</p>
                    <hr>
                    <h2>Flight Options</h2>
                    ${flightsHtml}
                    <hr>
                    <h2>Accommodation Suggestions</h2>
                    ${accommodationsHtml}
                    <hr>
                    <h2>Daily Itinerary</h2>
                    ${dailyItineraryHtml}
                    <hr>
                    <br/><p>Happy travels!</p><p>The ZoomZoot Team</p>
                </div>
            `;

            await SendEmail({
                to: user.email,
                subject: `Your Standard Travel Plan: ${trip.title}`,
                body: emailBody,
            });
            
            toast({
                title: "Email Sent Successfully! 📧",
                description: "Check your inbox for the complete itinerary.",
            });

        } catch (error) {
            console.error("Failed to send email:", error);
            toast({
                variant: "destructive",
                title: "Email Failed",
                description: "Could not send the email. Please try again.",
            });
        }
        setIsEmailSending(false);
    };

    return (
        <>
            <Toaster />
            <div className="max-w-md mx-auto p-6 text-center space-y-6 pt-16">
                <motion.div
                    initial={{ opacity: 0, scale: 0.5 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.5, type: 'spring' }}
                >
                    <MascotIcon width={80} height={80} className="mx-auto mascot-pulse" />
                </motion.div>

                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                >
                    <CheckCircle className="w-16 h-16 text-green-400 mx-auto" />
                    <h1 className="text-3xl font-bold mt-4 text-white">Payment Successful!</h1>
                    <p className="text-white/90 mt-2">
                        Your <span className="font-semibold text-white">{planDetails.name}</span> purchase is complete.
                    </p>
                    <div className="bg-green-500/20 border border-green-400/50 rounded-lg p-3 mt-4">
                        <p className="text-green-100">Successfully charged: {planDetails.price}</p>
                    </div>
                </motion.div>

                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                    className="space-y-4 pt-4 border-t border-white/20"
                >
                    <h2 className="text-xl font-semibold text-white">What's Next?</h2>
                    <p className="text-white/90">{planDetails.description}</p>
                    
                    {trip && (
                        <Button 
                            onClick={handleSendEmail}
                            disabled={isEmailSending}
                            className="w-full h-12 bg-green-600 hover:bg-green-700 text-white mb-4"
                        >
                            <Mail className="w-4 h-4 mr-2" />
                            {isEmailSending ? 'Sending Email...' : 'Email My Itinerary'}
                        </Button>
                    )}
                    
                    <Button asChild className="w-full h-12" style={{ background: 'linear-gradient(135deg, #297479 0%, #aab624 100%)', color: 'white' }}>
                        <Link to={createPageUrl("MyTrips")}>
                            <Plane className="w-4 h-4 mr-2" />
                            View My Trips
                        </Link>
                    </Button>
                    
                    <Button asChild variant="outline" className="w-full h-12 border-2 border-white/50 text-green-500 hover:bg-white/10 hover:text-green-400">
                        <Link to={createPageUrl("CurrencyConverter")}>
                            <Calculator className="w-4 h-4 mr-2" />
                            Try Converter
                        </Link>
                    </Button>
                </motion.div>
            </div>
        </>
    );
}